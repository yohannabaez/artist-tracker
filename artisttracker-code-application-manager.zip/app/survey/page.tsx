import { ArtistSurvey } from "@/components/artist-survey"

export default function SurveyPage() {
  return <ArtistSurvey />
}
