import { ApplicationSourceTracker } from "@/components/application-source-tracker"
import { OpportunityImportMethods } from "@/components/opportunity-import-methods"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SourceTrackerPage() {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Source & Import Management</h1>
      <p className="text-muted-foreground mb-8 max-w-3xl">
        Track where your applications come from and import new opportunities from various sources including websites,
        spreadsheets, and integrated platforms.
      </p>

      <Tabs defaultValue="tracker" className="space-y-6">
        <TabsList>
          <TabsTrigger value="tracker">Source Tracker</TabsTrigger>
          <TabsTrigger value="import">Import Methods</TabsTrigger>
        </TabsList>

        <TabsContent value="tracker">
          <ApplicationSourceTracker />
        </TabsContent>

        <TabsContent value="import">
          <OpportunityImportMethods />
        </TabsContent>
      </Tabs>
    </div>
  )
}
