import Link from "next/link"
import { CalendarDays, Clock, DollarSign, FileText, PlusCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UpcomingDeadlines } from "@/components/upcoming-deadlines"
import { ApplicationStats } from "@/components/application-stats"
import { RecommendedOpportunities } from "@/components/recommended-opportunities"
import { ApplicationFeeTracker } from "@/components/application-fee-tracker"
import { BurnoutWidget } from "@/components/burnout-widget"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <FileText className="h-6 w-6" />
            <span className="text-xl font-bold">ArtistTracker</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/calendar" className="text-sm font-medium text-muted-foreground">
              Calendar
            </Link>
            <Link href="/opportunities" className="text-sm font-medium text-muted-foreground">
              Opportunities
            </Link>
            <Link href="/film-opportunities" className="text-sm font-medium text-muted-foreground">
              Film & Screenplay
            </Link>
            <Link href="/source-tracker" className="text-sm font-medium text-muted-foreground">
              Source Tracker
            </Link>
            <Link href="/integrations" className="text-sm font-medium text-muted-foreground">
              Integrations
            </Link>
            <Link href="/mood-tracker" className="text-sm font-medium text-muted-foreground">
              Mood Tracker
            </Link>
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="hidden md:flex">
              <Clock className="mr-2 h-4 w-4" />
              Reminders
            </Button>
            <Button size="sm">
              <PlusCircle className="mr-2 h-4 w-4" />
              New Application
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <CalendarDays className="mr-2 h-4 w-4" />
                Sync Calendar
              </Button>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Applications</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">+2 from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Upcoming Deadlines</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4</div>
                <p className="text-xs text-muted-foreground">Next: Emerging Artist Grant (3 days)</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Application Fees</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$475</div>
                <p className="text-xs text-muted-foreground">Spent this year</p>
              </CardContent>
            </Card>
            <BurnoutWidget />
          </div>

          <Tabs defaultValue="upcoming">
            <TabsList>
              <TabsTrigger value="upcoming">Upcoming Deadlines</TabsTrigger>
              <TabsTrigger value="stats">Application Stats</TabsTrigger>
              <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
              <TabsTrigger value="fees">Fee Tracker</TabsTrigger>
            </TabsList>
            <TabsContent value="upcoming" className="space-y-4">
              <UpcomingDeadlines />
            </TabsContent>
            <TabsContent value="stats" className="space-y-4">
              <ApplicationStats />
            </TabsContent>
            <TabsContent value="recommendations" className="space-y-4">
              <RecommendedOpportunities />
            </TabsContent>
            <TabsContent value="fees" className="space-y-4">
              <ApplicationFeeTracker />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
