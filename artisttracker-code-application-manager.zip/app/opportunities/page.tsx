import { OpportunitySources } from "@/components/opportunity-sources"

export default function OpportunitiesPage() {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Opportunity Explorer</h1>
      <p className="text-muted-foreground mb-8 max-w-3xl">
        Browse opportunities from multiple platforms including CaFÉ, Residency Unlimited, Rivet, China Residencies, and
        Creative Capital. Filter by type, deadline, and more to find the perfect opportunities for your artistic
        practice.
      </p>
      <OpportunitySources />
    </div>
  )
}
