import { MobileAppPreview } from "@/components/mobile-app-preview"

export default function MobilePreviewPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Mobile App Concept</h1>
      <p className="mb-8 text-muted-foreground max-w-2xl">
        A complementary mobile app would provide on-the-go access to your application information, push notifications
        for deadlines, and integration with your phone's native features.
      </p>

      <div className="flex flex-col md:flex-row gap-8 items-start">
        <MobileAppPreview />

        <div className="flex-1 space-y-6">
          <div>
            <h2 className="text-2xl font-bold mb-2">Key Mobile Features</h2>
            <ul className="list-disc pl-5 space-y-2">
              <li>Push notifications for upcoming deadlines</li>
              <li>Quick access to application details on the go</li>
              <li>Offline access to your application information</li>
              <li>Document scanning for application materials and receipts</li>
              <li>Integration with your phone's native calendar</li>
              <li>Voice notes for application ideas</li>
            </ul>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-2">Benefits of a Dual Approach</h2>
            <p className="mb-4">
              The web application and mobile app would work together to provide a comprehensive solution:
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="border rounded-lg p-4">
                <h3 className="font-bold mb-2">Web Application</h3>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li>Complex form filling and document uploads</li>
                  <li>Detailed data visualization and statistics</li>
                  <li>In-depth opportunity research</li>
                  <li>Document editing and management</li>
                  <li>Budget planning and tracking</li>
                </ul>
              </div>
              <div className="border rounded-lg p-4">
                <h3 className="font-bold mb-2">Mobile App</h3>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li>On-the-go notifications and reminders</li>
                  <li>Quick deadline checks</li>
                  <li>Opportunity browsing during downtime</li>
                  <li>Document scanning and photo capture</li>
                  <li>Voice memos for application ideas</li>
                </ul>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-2">Implementation Approach</h2>
            <p>
              The most efficient approach would be to develop a responsive web application first, followed by mobile
              apps for iOS and Android using a cross-platform framework like React Native. This would allow for code
              sharing between the web and mobile versions while providing native mobile experiences.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
