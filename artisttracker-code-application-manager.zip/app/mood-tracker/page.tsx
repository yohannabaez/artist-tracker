import { MoodTracker } from "@/components/mood-tracker"

export default function MoodTrackerPage() {
  return (
    <div className="container py-6">
      <MoodTracker />
    </div>
  )
}
