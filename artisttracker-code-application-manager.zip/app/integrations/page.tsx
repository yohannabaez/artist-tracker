import { OpportunityIntegration } from "@/components/opportunity-integration"

export default function IntegrationsPage() {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Platform Integrations</h1>
      <p className="text-muted-foreground mb-8 max-w-3xl">
        Connect your Artist Application Manager to various opportunity platforms to automatically import and track
        applications. This allows you to manage all your opportunities in one place without having to manually enter
        information.
      </p>
      <OpportunityIntegration />
    </div>
  )
}
