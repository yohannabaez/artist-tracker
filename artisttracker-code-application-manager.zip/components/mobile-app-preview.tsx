"use client"

import { useState } from "react"
import { Bell, Calendar, Home, Menu, Search, Settings } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Tabs, TabsContent } from "@/components/ui/tabs"

export function MobileAppPreview() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <h2 className="text-2xl font-bold mb-6">Mobile App Preview</h2>

      <div className="w-full max-w-[320px] h-[640px] rounded-[32px] border-8 border-gray-800 overflow-hidden bg-background shadow-xl flex flex-col">
        {/* Phone Status Bar */}
        <div className="h-6 bg-gray-800 w-full flex items-center justify-between px-4">
          <div className="text-white text-xs">9:41</div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-white"></div>
            <div className="w-2 h-2 rounded-full bg-white"></div>
            <div className="w-2 h-2 rounded-full bg-white"></div>
          </div>
        </div>

        {/* App Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <Button variant="ghost" size="icon" onClick={() => setMenuOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-1">
            <span className="font-bold">ArtistTracker</span>
          </div>
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500"></span>
          </Button>
        </div>

        {/* App Content */}
        <div className="flex-1 overflow-auto">
          <Tabs defaultValue="home" className="w-full">
            <TabsContent value="home" className="p-4 space-y-4 mt-0">
              <div className="space-y-2">
                <h3 className="font-semibold">Upcoming Deadlines</h3>
                <Card className="border-l-4 border-l-orange-500">
                  <CardHeader className="p-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-sm">Emerging Artist Grant</CardTitle>
                      <Badge
                        variant="outline"
                        className="text-[10px] bg-orange-100 text-orange-800 hover:bg-orange-100"
                      >
                        3 days
                      </Badge>
                    </div>
                    <CardDescription className="text-xs">National Arts Foundation</CardDescription>
                  </CardHeader>
                </Card>
                <Card className="border-l-4 border-l-yellow-500">
                  <CardHeader className="p-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-sm">City Artist Fellowship</CardTitle>
                      <Badge
                        variant="outline"
                        className="text-[10px] bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                      >
                        7 days
                      </Badge>
                    </div>
                    <CardDescription className="text-xs">Metropolitan Arts Council</CardDescription>
                  </CardHeader>
                </Card>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">Recommended For You</h3>
                <Card>
                  <CardHeader className="p-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-sm">Digital Art Fellowship</CardTitle>
                      <Badge className="text-[10px]">98% Match</Badge>
                    </div>
                    <CardDescription className="text-xs">Tech Arts Foundation</CardDescription>
                  </CardHeader>
                  <CardFooter className="p-3 pt-0">
                    <Button size="sm" className="w-full text-xs">
                      View Details
                    </Button>
                  </CardFooter>
                </Card>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">Application Stats</h3>
                <div className="grid grid-cols-2 gap-2">
                  <Card>
                    <CardHeader className="p-3">
                      <CardTitle className="text-xs">Active Applications</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-0">
                      <div className="text-xl font-bold">12</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="p-3">
                      <CardTitle className="text-xs">Fees Spent</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-0">
                      <div className="text-xl font-bold">$475</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Bottom Navigation */}
        <div className="flex justify-around items-center p-2 border-t bg-background">
          <Button variant="ghost" size="icon" className="flex flex-col items-center justify-center h-14 w-14">
            <Home className="h-5 w-5" />
            <span className="text-[10px] mt-1">Home</span>
          </Button>
          <Button variant="ghost" size="icon" className="flex flex-col items-center justify-center h-14 w-14">
            <Search className="h-5 w-5" />
            <span className="text-[10px] mt-1">Explore</span>
          </Button>
          <Button variant="ghost" size="icon" className="flex flex-col items-center justify-center h-14 w-14">
            <Calendar className="h-5 w-5" />
            <span className="text-[10px] mt-1">Calendar</span>
          </Button>
          <Button variant="ghost" size="icon" className="flex flex-col items-center justify-center h-14 w-14">
            <Settings className="h-5 w-5" />
            <span className="text-[10px] mt-1">Settings</span>
          </Button>
        </div>
      </div>

      {/* Side Menu */}
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent side="left" className="w-[250px] sm:w-[300px]">
          <SheetHeader>
            <SheetTitle>Menu</SheetTitle>
          </SheetHeader>
          <div className="py-4">
            <div className="space-y-4">
              <Button variant="ghost" className="w-full justify-start" onClick={() => setMenuOpen(false)}>
                <Home className="mr-2 h-4 w-4" />
                Dashboard
              </Button>
              <Button variant="ghost" className="w-full justify-start" onClick={() => setMenuOpen(false)}>
                <Calendar className="mr-2 h-4 w-4" />
                Calendar
              </Button>
              <Button variant="ghost" className="w-full justify-start" onClick={() => setMenuOpen(false)}>
                <Search className="mr-2 h-4 w-4" />
                Opportunities
              </Button>
              <Button variant="ghost" className="w-full justify-start" onClick={() => setMenuOpen(false)}>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
