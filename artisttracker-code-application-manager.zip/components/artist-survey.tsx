"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { ArrowLeft, ArrowRight, CheckCircle2, Send } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Progress } from "@/components/ui/progress"

// Define the schema for each step of the form
const personalInfoSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  artistType: z.string().min(1, { message: "Please select your primary artistic practice." }),
  careerStage: z.string().min(1, { message: "Please select your career stage." }),
  website: z.string().url().optional().or(z.literal("")),
  location: z.string().min(2, { message: "Please enter your location." }),
})

const applicationHabitsSchema = z.object({
  applicationsPerYear: z.string().min(1, { message: "Please select an option." }),
  trackingMethod: z.string().min(1, { message: "Please select how you currently track applications." }),
  successRate: z.string().min(1, { message: "Please select your approximate success rate." }),
  spendOnFees: z.string().min(1, { message: "Please select how much you spend on application fees annually." }),
  timeSpent: z.string().min(1, { message: "Please select how much time you spend on applications." }),
})

const opportunityTypesSchema = z.object({
  opportunityTypes: z.array(z.string()).min(1, { message: "Please select at least one opportunity type." }),
  otherOpportunityTypes: z.string().optional(),
})

const painPointsSchema = z.object({
  challenges: z.array(z.string()).min(1, { message: "Please select at least one challenge." }),
  otherChallenges: z.string().optional(),
  missedDeadlines: z.string().min(1, { message: "Please select an option." }),
  organizationLevel: z.string().min(1, { message: "Please rate your current level of organization." }),
})

const burnoutExperienceSchema = z.object({
  experiencedBurnout: z.string().min(1, { message: "Please select an option." }),
  burnoutFrequency: z.string().optional(),
  burnoutSeverity: z.array(z.number()).optional(),
  burnoutRecovery: z.string().optional(),
  wellnessStrategies: z.string().optional(),
})

const featurePrioritiesSchema = z.object({
  mustHaveFeatures: z.array(z.string()).min(1, { message: "Please select at least one must-have feature." }),
  niceToHaveFeatures: z.array(z.string()).optional(),
  customFeatures: z.string().optional(),
})

const technicalPreferencesSchema = z.object({
  deviceUsage: z.array(z.string()).min(1, { message: "Please select at least one device." }),
  techComfort: z.string().min(1, { message: "Please rate your comfort with technology." }),
  notificationPreferences: z.array(z.string()).min(1, { message: "Please select at least one notification method." }),
  dataImport: z.string().min(1, { message: "Please select an option." }),
})

const visualPreferencesSchema = z.object({
  colorPreference: z.string().min(1, { message: "Please select a color scheme preference." }),
  layoutPreference: z.string().min(1, { message: "Please select a layout preference." }),
  accessibilityNeeds: z.array(z.string()).optional(),
  otherAccessibilityNeeds: z.string().optional(),
})

const additionalInfoSchema = z.object({
  otherTools: z.string().optional(),
  budgetRange: z.string().min(1, { message: "Please select a budget range." }),
  additionalComments: z.string().optional(),
})

// Define the steps of the survey
const steps = [
  {
    id: "personal-info",
    name: "Personal Information",
    description: "Tell us about yourself and your artistic practice.",
    schema: personalInfoSchema,
  },
  {
    id: "application-habits",
    name: "Application Habits",
    description: "Share your current application process and experience.",
    schema: applicationHabitsSchema,
  },
  {
    id: "opportunity-types",
    name: "Opportunity Types",
    description: "What types of opportunities do you typically apply for?",
    schema: opportunityTypesSchema,
  },
  {
    id: "pain-points",
    name: "Challenges & Pain Points",
    description: "What difficulties do you face when applying for opportunities?",
    schema: painPointsSchema,
  },
  {
    id: "burnout-experience",
    name: "Burnout Experience",
    description: "Tell us about your experience with application fatigue and burnout.",
    schema: burnoutExperienceSchema,
  },
  {
    id: "feature-priorities",
    name: "Feature Priorities",
    description: "What features would be most valuable to you?",
    schema: featurePrioritiesSchema,
  },
  {
    id: "technical-preferences",
    name: "Technical Preferences",
    description: "Tell us about your technology usage and preferences.",
    schema: technicalPreferencesSchema,
  },
  {
    id: "visual-preferences",
    name: "Visual Preferences",
    description: "What visual style do you prefer for the application?",
    schema: visualPreferencesSchema,
  },
  {
    id: "additional-info",
    name: "Additional Information",
    description: "Any other details that would help us build the right tool for you.",
    schema: additionalInfoSchema,
  },
]

// Define the opportunity types
const opportunityTypes = [
  { id: "grants", label: "Grants" },
  { id: "residencies", label: "Residencies" },
  { id: "fellowships", label: "Fellowships" },
  { id: "exhibitions", label: "Exhibitions" },
  { id: "commissions", label: "Commissions" },
  { id: "public-art", label: "Public Art Projects" },
  { id: "competitions", label: "Competitions" },
  { id: "festivals", label: "Festivals" },
  { id: "scholarships", label: "Scholarships" },
  { id: "teaching", label: "Teaching Positions" },
]

// Define the challenges
const challenges = [
  { id: "deadlines", label: "Keeping track of deadlines" },
  { id: "requirements", label: "Managing different application requirements" },
  { id: "materials", label: "Organizing application materials" },
  { id: "fees", label: "Tracking application fees" },
  { id: "follow-up", label: "Following up on submitted applications" },
  { id: "feedback", label: "Getting feedback on rejected applications" },
  { id: "finding", label: "Finding relevant opportunities" },
  { id: "time", label: "Finding time to complete applications" },
  { id: "burnout", label: "Application fatigue/burnout" },
  { id: "motivation", label: "Maintaining motivation after rejections" },
]

// Define the features
const features = [
  { id: "deadline-tracking", label: "Deadline tracking and reminders" },
  { id: "calendar-integration", label: "Calendar integration" },
  { id: "application-templates", label: "Application templates and reusable content" },
  { id: "document-storage", label: "Document storage and organization" },
  { id: "fee-tracking", label: "Application fee tracking" },
  { id: "opportunity-database", label: "Opportunity database" },
  { id: "recommendation-engine", label: "Personalized opportunity recommendations" },
  { id: "status-tracking", label: "Application status tracking" },
  { id: "analytics", label: "Success rate analytics" },
  { id: "burnout-meter", label: "Burnout meter and wellness tools" },
  { id: "collaboration", label: "Collaboration tools for feedback" },
  { id: "mobile-app", label: "Mobile app access" },
  { id: "export", label: "Data export capabilities" },
  { id: "budget-tracking", label: "Budget tracking for project proposals" },
]

// Define the notification methods
const notificationMethods = [
  { id: "email", label: "Email" },
  { id: "sms", label: "SMS/Text message" },
  { id: "push", label: "Mobile push notifications" },
  { id: "calendar", label: "Calendar alerts" },
  { id: "in-app", label: "In-app notifications only" },
]

// Define the accessibility needs
const accessibilityNeeds = [
  { id: "screen-reader", label: "Screen reader compatibility" },
  { id: "keyboard-navigation", label: "Keyboard navigation" },
  { id: "color-contrast", label: "High color contrast" },
  { id: "text-size", label: "Adjustable text size" },
  { id: "reduced-motion", label: "Reduced motion" },
  { id: "voice-control", label: "Voice control compatibility" },
]

export function ArtistSurvey() {
  const [step, setStep] = useState(0)
  const [formData, setFormData] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  // Create a form for the current step
  const form = useForm({
    resolver: zodResolver(steps[step].schema),
    defaultValues: formData[steps[step].id] || {},
  })

  // Handle form submission for each step
  const onSubmit = (data: any) => {
    // Update form data with the current step's data
    const updatedFormData = {
      ...formData,
      [steps[step].id]: data,
    }
    setFormData(updatedFormData)

    // If this is the last step, submit the form
    if (step === steps.length - 1) {
      setIsSubmitting(true)
      // In a real application, you would send the data to your backend here
      console.log("Form submitted:", updatedFormData)
      setTimeout(() => {
        setIsSubmitting(false)
        setIsComplete(true)
      }, 1500)
      return
    }

    // Otherwise, go to the next step
    setStep(step + 1)
  }

  // Handle going back to the previous step
  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1)
    }
  }

  // Calculate progress percentage
  const progress = ((step + 1) / steps.length) * 100

  // Render the form for the current step
  const renderStepContent = () => {
    switch (steps[step].id) {
      case "personal-info":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Your name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="your.email@example.com" type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="artistType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Artistic Practice</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your primary artistic practice" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="visual">Visual Artist</SelectItem>
                      <SelectItem value="digital">Digital Artist</SelectItem>
                      <SelectItem value="performance">Performance Artist</SelectItem>
                      <SelectItem value="music">Musician/Composer</SelectItem>
                      <SelectItem value="writing">Writer/Poet</SelectItem>
                      <SelectItem value="film">Filmmaker</SelectItem>
                      <SelectItem value="photography">Photographer</SelectItem>
                      <SelectItem value="sculpture">Sculptor</SelectItem>
                      <SelectItem value="installation">Installation Artist</SelectItem>
                      <SelectItem value="mixed">Mixed Media Artist</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="careerStage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Career Stage</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your career stage" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="emerging">Emerging (0-5 years)</SelectItem>
                      <SelectItem value="mid-career">Mid-Career (5-15 years)</SelectItem>
                      <SelectItem value="established">Established (15+ years)</SelectItem>
                      <SelectItem value="student">Student</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="website"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Website or Portfolio URL (optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="https://yourwebsite.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location</FormLabel>
                  <FormControl>
                    <Input placeholder="City, Country" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "application-habits":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="applicationsPerYear"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How many opportunities do you apply for annually?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a range" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="0-5">0-5 applications</SelectItem>
                      <SelectItem value="6-10">6-10 applications</SelectItem>
                      <SelectItem value="11-20">11-20 applications</SelectItem>
                      <SelectItem value="21-50">21-50 applications</SelectItem>
                      <SelectItem value="50+">More than 50 applications</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="trackingMethod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How do you currently track your applications?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your current method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">I don't track them systematically</SelectItem>
                      <SelectItem value="paper">Paper notes/calendar</SelectItem>
                      <SelectItem value="spreadsheet">Spreadsheet (Excel, Google Sheets)</SelectItem>
                      <SelectItem value="calendar">Digital calendar (Google Calendar, iCal)</SelectItem>
                      <SelectItem value="task-app">Task management app (Trello, Asana, etc.)</SelectItem>
                      <SelectItem value="specialized">Specialized application tracking software</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="successRate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What is your approximate success rate with applications?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your success rate" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="0-5">Less than 5%</SelectItem>
                      <SelectItem value="5-10">5-10%</SelectItem>
                      <SelectItem value="10-20">10-20%</SelectItem>
                      <SelectItem value="20-30">20-30%</SelectItem>
                      <SelectItem value="30-50">30-50%</SelectItem>
                      <SelectItem value="50+">More than 50%</SelectItem>
                      <SelectItem value="unknown">I don't know</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="spendOnFees"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How much do you spend on application fees annually?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a range" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="0">$0 (I only apply to opportunities without fees)</SelectItem>
                      <SelectItem value="1-100">$1-$100</SelectItem>
                      <SelectItem value="101-250">$101-$250</SelectItem>
                      <SelectItem value="251-500">$251-$500</SelectItem>
                      <SelectItem value="501-1000">$501-$1,000</SelectItem>
                      <SelectItem value="1000+">More than $1,000</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="timeSpent"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How much time do you spend on applications monthly?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a range" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="0-5">0-5 hours</SelectItem>
                      <SelectItem value="6-10">6-10 hours</SelectItem>
                      <SelectItem value="11-20">11-20 hours</SelectItem>
                      <SelectItem value="21-40">21-40 hours</SelectItem>
                      <SelectItem value="40+">More than 40 hours</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "opportunity-types":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="opportunityTypes"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel>What types of opportunities do you typically apply for?</FormLabel>
                    <FormDescription>Select all that apply.</FormDescription>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {opportunityTypes.map((item) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name="opportunityTypes"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={item.id}
                              className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(item.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...field.value, item.id])
                                      : field.onChange(field.value?.filter((value: string) => value !== item.id))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">{item.label}</FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="otherOpportunityTypes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Other opportunity types (please specify)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Enter any other types of opportunities you apply for" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "pain-points":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="challenges"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel>What challenges do you face when applying for opportunities?</FormLabel>
                    <FormDescription>Select all that apply.</FormDescription>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {challenges.map((item) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name="challenges"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={item.id}
                              className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(item.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...field.value, item.id])
                                      : field.onChange(field.value?.filter((value: string) => value !== item.id))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">{item.label}</FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="otherChallenges"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Other challenges (please specify)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Enter any other challenges you face" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="missedDeadlines"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How often do you miss application deadlines?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="never" />
                        </FormControl>
                        <FormLabel className="font-normal">Never</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="rarely" />
                        </FormControl>
                        <FormLabel className="font-normal">Rarely</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="sometimes" />
                        </FormControl>
                        <FormLabel className="font-normal">Sometimes</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="often" />
                        </FormControl>
                        <FormLabel className="font-normal">Often</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="very-often" />
                        </FormControl>
                        <FormLabel className="font-normal">Very often</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="organizationLevel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How would you rate your current level of organization for applications?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="very-disorganized" />
                        </FormControl>
                        <FormLabel className="font-normal">Very disorganized</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="somewhat-disorganized" />
                        </FormControl>
                        <FormLabel className="font-normal">Somewhat disorganized</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="neutral" />
                        </FormControl>
                        <FormLabel className="font-normal">Neutral</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="somewhat-organized" />
                        </FormControl>
                        <FormLabel className="font-normal">Somewhat organized</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="very-organized" />
                        </FormControl>
                        <FormLabel className="font-normal">Very organized</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "burnout-experience":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="experiencedBurnout"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Have you ever experienced burnout from applying to opportunities?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="yes" />
                        </FormControl>
                        <FormLabel className="font-normal">Yes</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="no" />
                        </FormControl>
                        <FormLabel className="font-normal">No</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3  space-y-0">
                        <FormControl>
                          <RadioGroupItem value="not-sure" />
                        </FormControl>
                        <FormLabel className="font-normal">Not sure</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            {form.watch("experiencedBurnout") === "yes" && (
              <>
                <FormField
                  control={form.control}
                  name="burnoutFrequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>How often do you experience application burnout?</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="rarely">Rarely (once a year or less)</SelectItem>
                          <SelectItem value="occasionally">Occasionally (a few times a year)</SelectItem>
                          <SelectItem value="frequently">Frequently (monthly)</SelectItem>
                          <SelectItem value="constantly">Constantly (ongoing)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="burnoutSeverity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        On a scale of 1-10, how would you rate the severity of your application burnout?
                      </FormLabel>
                      <FormControl>
                        <Slider
                          defaultValue={field.value || [5]}
                          max={10}
                          step={1}
                          onValueChange={field.onChange}
                          className="py-4"
                        />
                      </FormControl>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Mild (1)</span>
                        <span>Moderate (5)</span>
                        <span>Severe (10)</span>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="burnoutRecovery"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>How do you currently recover from application burnout?</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe your recovery strategies (e.g., taking breaks, creative activities, etc.)"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}
            <FormField
              control={form.control}
              name="wellnessStrategies"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    What wellness strategies would you like to see integrated into an application management tool?
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe any wellness features that would help you maintain balance"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "feature-priorities":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="mustHaveFeatures"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel>Which features are must-haves for you?</FormLabel>
                    <FormDescription>Select all that apply.</FormDescription>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {features.map((item) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name="mustHaveFeatures"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={item.id}
                              className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(item.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...field.value, item.id])
                                      : field.onChange(field.value?.filter((value: string) => value !== item.id))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">{item.label}</FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="niceToHaveFeatures"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel>Which features would be nice to have but aren't essential?</FormLabel>
                    <FormDescription>Select all that apply.</FormDescription>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {features.map((item) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name="niceToHaveFeatures"
                        render={({ field }) => {
                          // Don't show features that are already selected as must-haves
                          const mustHaves = form.watch("mustHaveFeatures") || []
                          if (mustHaves.includes(item.id)) return null

                          return (
                            <FormItem
                              key={item.id}
                              className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(item.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...(field.value || []), item.id])
                                      : field.onChange(field.value?.filter((value: string) => value !== item.id) || [])
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">{item.label}</FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="customFeatures"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Are there any other features you'd like to see?</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe any additional features you'd find valuable" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "technical-preferences":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="deviceUsage"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel>Which devices would you use to access the application?</FormLabel>
                    <FormDescription>Select all that apply.</FormDescription>
                  </div>
                  <div className="space-y-2">
                    <FormField
                      control={form.control}
                      name="deviceUsage"
                      render={({ field }) => {
                        return (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3">
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes("desktop")}
                                onCheckedChange={(checked) => {
                                  return checked
                                    ? field.onChange([...field.value, "desktop"])
                                    : field.onChange(field.value?.filter((value: string) => value !== "desktop"))
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">Desktop/Laptop Computer</FormLabel>
                          </FormItem>
                        )
                      }}
                    />
                    <FormField
                      control={form.control}
                      name="deviceUsage"
                      render={({ field }) => {
                        return (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3">
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes("tablet")}
                                onCheckedChange={(checked) => {
                                  return checked
                                    ? field.onChange([...field.value, "tablet"])
                                    : field.onChange(field.value?.filter((value: string) => value !== "tablet"))
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">Tablet</FormLabel>
                          </FormItem>
                        )
                      }}
                    />
                    <FormField
                      control={form.control}
                      name="deviceUsage"
                      render={({ field }) => {
                        return (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3">
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes("smartphone")}
                                onCheckedChange={(checked) => {
                                  return checked
                                    ? field.onChange([...field.value, "smartphone"])
                                    : field.onChange(field.value?.filter((value: string) => value !== "smartphone"))
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">Smartphone</FormLabel>
                          </FormItem>
                        )
                      }}
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="techComfort"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How would you rate your comfort level with technology?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="beginner" />
                        </FormControl>
                        <FormLabel className="font-normal">Beginner - I struggle with new technology</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="intermediate" />
                        </FormControl>
                        <FormLabel className="font-normal">
                          Intermediate - I can learn new tools with some guidance
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="advanced" />
                        </FormControl>
                        <FormLabel className="font-normal">Advanced - I'm comfortable with most technology</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="expert" />
                        </FormControl>
                        <FormLabel className="font-normal">Expert - I pick up new tools very quickly</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notificationPreferences"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel>How would you prefer to receive notifications and reminders?</FormLabel>
                    <FormDescription>Select all that apply.</FormDescription>
                  </div>
                  <div className="space-y-2">
                    {notificationMethods.map((item) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name="notificationPreferences"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={item.id}
                              className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(item.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...field.value, item.id])
                                      : field.onChange(field.value?.filter((value: string) => value !== item.id))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">{item.label}</FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="dataImport"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Would you want to import existing application data?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="yes-spreadsheet" />
                        </FormControl>
                        <FormLabel className="font-normal">Yes, from a spreadsheet</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="yes-calendar" />
                        </FormControl>
                        <FormLabel className="font-normal">Yes, from my calendar</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="yes-other" />
                        </FormControl>
                        <FormLabel className="font-normal">Yes, from another source</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="no" />
                        </FormControl>
                        <FormLabel className="font-normal">No, I'll start fresh</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "visual-preferences":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="colorPreference"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What color scheme would you prefer for the interface?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="light" />
                        </FormControl>
                        <FormLabel className="font-normal">Light mode</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="dark" />
                        </FormControl>
                        <FormLabel className="font-normal">Dark mode</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="system" />
                        </FormControl>
                        <FormLabel className="font-normal">Follow system preference</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="colorful" />
                        </FormControl>
                        <FormLabel className="font-normal">Colorful/Artistic</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="layoutPreference"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What type of layout do you prefer?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="minimal" />
                        </FormControl>
                        <FormLabel className="font-normal">Minimal - clean with lots of white space</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="compact" />
                        </FormControl>
                        <FormLabel className="font-normal">Compact - more information on screen</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="visual" />
                        </FormControl>
                        <FormLabel className="font-normal">Visual - more graphics and charts</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="customizable" />
                        </FormControl>
                        <FormLabel className="font-normal">Customizable - I want to arrange it myself</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="accessibilityNeeds"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel>Do you have any accessibility needs?</FormLabel>
                    <FormDescription>Select all that apply.</FormDescription>
                  </div>
                  <div className="space-y-2">
                    {accessibilityNeeds.map((item) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name="accessibilityNeeds"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={item.id}
                              className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(item.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...(field.value || []), item.id])
                                      : field.onChange(field.value?.filter((value: string) => value !== item.id) || [])
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">{item.label}</FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="otherAccessibilityNeeds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Other accessibility needs (please specify)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Enter any other accessibility needs you have" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      case "additional-info":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="otherTools"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What other tools do you currently use in your application process?</FormLabel>
                  <FormControl>
                    <Textarea placeholder="List any tools, websites, or services you use for applications" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="budgetRange"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What would be your budget range for an application management tool?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a budget range" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="free">Free only</SelectItem>
                      <SelectItem value="0-5">$1-$5 per month</SelectItem>
                      <SelectItem value="6-10">$6-$10 per month</SelectItem>
                      <SelectItem value="11-20">$11-$20 per month</SelectItem>
                      <SelectItem value="21-50">$21-$50 per month</SelectItem>
                      <SelectItem value="50+">More than $50 per month</SelectItem>
                      <SelectItem value="one-time">I prefer a one-time purchase</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="additionalComments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Any additional comments or suggestions?</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Share any other thoughts that would help us build a better tool for you"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )
      default:
        return null
    }
  }

  // Render the completion screen
  const renderCompletionScreen = () => {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="rounded-full bg-green-100 p-3 mb-4">
          <CheckCircle2 className="h-12 w-12 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Thank You!</h2>
        <p className="text-muted-foreground mb-6 max-w-md">
          Your responses will help us build a better application management tool for artists. We appreciate your time
          and input.
        </p>
        <Button onClick={() => console.log("View full survey data:", formData)}>View Your Responses</Button>
      </div>
    )
  }

  return (
    <div className="container py-10 max-w-3xl">
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Artist Application Manager Survey</CardTitle>
          <CardDescription>
            Help us build a better tool for managing your grant, residency, and opportunity applications.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isComplete ? (
            <>
              <div className="mb-8">
                <div className="flex justify-between mb-2 text-sm">
                  <span>
                    Step {step + 1} of {steps.length}
                  </span>
                  <span>{Math.round(progress)}% complete</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              <div className="mb-6">
                <h2 className="text-xl font-semibold">{steps[step].name}</h2>
                <p className="text-muted-foreground">{steps[step].description}</p>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {renderStepContent()}
                  <div className="flex justify-between pt-4">
                    <Button type="button" variant="outline" onClick={handleBack} disabled={step === 0}>
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Back
                    </Button>
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? (
                        "Submitting..."
                      ) : step === steps.length - 1 ? (
                        <>
                          Submit
                          <Send className="ml-2 h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Next
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </>
          ) : (
            renderCompletionScreen()
          )}
        </CardContent>
      </Card>
    </div>
  )
}
