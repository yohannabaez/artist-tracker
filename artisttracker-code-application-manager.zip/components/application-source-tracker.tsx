"use client"

import { useState } from "react"
import { ExternalLink, Info, Tag, Clock, ArrowUpRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Progress } from "@/components/ui/progress"

// Sample application data with source tracking
const applications = [
  {
    id: "app-001",
    title: "Annual Juried Exhibition",
    organization: "National Art Gallery",
    status: "Submitted",
    deadline: "2025-06-15",
    submissionDate: "2025-06-10",
    source: {
      name: "CaFÉ",
      url: "https://artist.callforentry.org",
      logo: "/logos/cafe-logo.png",
      importMethod: "API Integration",
      importDate: "2025-05-20",
      originalId: "cafe-12345",
    },
    type: "Exhibition",
    fee: 35,
    notes: "Submitted all required materials including artist statement and 10 images.",
  },
  {
    id: "app-002",
    title: "Emerging Artists Residency Program",
    organization: "Residency Unlimited",
    status: "In Progress",
    deadline: "2025-07-30",
    submissionDate: null,
    source: {
      name: "Residency Unlimited",
      url: "https://residencyunlimited.org",
      logo: "/logos/ru-logo.png",
      importMethod: "Manual Entry",
      importDate: "2025-05-15",
      originalId: null,
    },
    type: "Residency",
    fee: 0,
    notes: "Need to complete artist statement and project proposal.",
  },
  {
    id: "app-003",
    title: "Digital Art Fellowship",
    organization: "Rivet Contemporary Art Center",
    status: "Accepted",
    deadline: "2025-04-10",
    submissionDate: "2025-04-05",
    source: {
      name: "Rivet",
      url: "https://rivet.es",
      logo: "/logos/rivet-logo.png",
      importMethod: "API Integration",
      importDate: "2025-03-15",
      originalId: "rivet-78901",
    },
    type: "Fellowship",
    fee: 20,
    notes: "Received acceptance notification on May 15, 2025. Need to confirm by June 1.",
  },
  {
    id: "app-004",
    title: "Screenplay Competition",
    organization: "Sundance Film Festival",
    status: "Submitted",
    deadline: "2025-05-30",
    submissionDate: "2025-05-28",
    source: {
      name: "Coverfly",
      url: "https://coverfly.com",
      logo: "/logos/coverfly-logo.png",
      importMethod: "API Integration",
      importDate: "2025-05-10",
      originalId: "coverfly-34567",
    },
    type: "Competition",
    fee: 50,
    notes: "Submitted screenplay 'The Last Light' with synopsis and logline.",
  },
  {
    id: "app-005",
    title: "International Short Film Festival",
    organization: "Berlin Short Film Festival",
    status: "In Progress",
    deadline: "2025-08-15",
    submissionDate: null,
    source: {
      name: "FilmFreeway",
      url: "https://filmfreeway.com",
      logo: "/logos/filmfreeway-logo.png",
      importMethod: "API Integration",
      importDate: "2025-06-01",
      originalId: "filmfreeway-56789",
    },
    type: "Festival",
    fee: 40,
    notes: "Need to upload final cut of film and subtitles.",
  },
  {
    id: "app-006",
    title: "Red Gate Residency",
    organization: "Red Gate Gallery",
    status: "Rejected",
    deadline: "2025-03-01",
    submissionDate: "2025-02-25",
    source: {
      name: "China Residencies",
      url: "https://www.chinaresidencies.com",
      logo: "/logos/china-logo.png",
      importMethod: "Web Scraping",
      importDate: "2025-01-20",
      originalId: "china-23456",
    },
    type: "Residency",
    fee: 50,
    notes: "Received rejection notification on April 10, 2025. Will apply again next year.",
  },
  {
    id: "app-007",
    title: "Creative Capital Grant",
    organization: "Creative Capital",
    status: "Submitted",
    deadline: "2025-02-28",
    submissionDate: "2025-02-27",
    source: {
      name: "Creative Capital",
      url: "https://creative-capital.org",
      logo: "/logos/cc-logo.png",
      importMethod: "API Integration",
      importDate: "2025-01-15",
      originalId: "cc-45678",
    },
    type: "Grant",
    fee: 0,
    notes: "Submitted project proposal and budget. Expecting response by July 2025.",
  },
  {
    id: "app-008",
    title: "Documentary Feature Competition",
    organization: "Hot Docs Film Festival",
    status: "Accepted",
    deadline: "2025-01-15",
    submissionDate: "2025-01-10",
    source: {
      name: "FilmFreeway",
      url: "https://filmfreeway.com",
      logo: "/logos/filmfreeway-logo.png",
      importMethod: "API Integration",
      importDate: "2024-12-20",
      originalId: "filmfreeway-67890",
    },
    type: "Festival",
    fee: 60,
    notes: "Film accepted for screening. Need to provide DCP by July 1.",
  },
]

// Source platforms with statistics
const sourcePlatforms = [
  {
    id: "cafe",
    name: "CaFÉ",
    url: "https://artist.callforentry.org",
    logo: "/logos/cafe-logo.png",
    applicationCount: 12,
    successRate: 25,
    averageFee: 35,
    lastSync: "2025-06-01T14:30:00",
    integrationMethod: "API Integration",
  },
  {
    id: "ru",
    name: "Residency Unlimited",
    url: "https://residencyunlimited.org",
    logo: "/logos/ru-logo.png",
    applicationCount: 5,
    successRate: 20,
    averageFee: 15,
    lastSync: "2025-05-28T10:15:00",
    integrationMethod: "Web Scraping",
  },
  {
    id: "rivet",
    name: "Rivet",
    url: "https://rivet.es",
    logo: "/logos/rivet-logo.png",
    applicationCount: 8,
    successRate: 37.5,
    averageFee: 20,
    lastSync: "2025-05-30T16:45:00",
    integrationMethod: "API Integration",
  },
  {
    id: "china",
    name: "China Residencies",
    url: "https://www.chinaresidencies.com",
    logo: "/logos/china-logo.png",
    applicationCount: 3,
    successRate: 0,
    averageFee: 50,
    lastSync: "2025-05-25T09:20:00",
    integrationMethod: "Web Scraping",
  },
  {
    id: "cc",
    name: "Creative Capital",
    url: "https://creative-capital.org",
    logo: "/logos/cc-logo.png",
    applicationCount: 2,
    successRate: 50,
    averageFee: 0,
    lastSync: "2025-05-29T11:30:00",
    integrationMethod: "API Integration",
  },
  {
    id: "coverfly",
    name: "Coverfly",
    url: "https://coverfly.com",
    logo: "/logos/coverfly-logo.png",
    applicationCount: 7,
    successRate: 28.6,
    averageFee: 45,
    lastSync: "2025-06-02T13:15:00",
    integrationMethod: "API Integration",
  },
  {
    id: "filmfreeway",
    name: "FilmFreeway",
    url: "https://filmfreeway.com",
    logo: "/logos/filmfreeway-logo.png",
    applicationCount: 10,
    successRate: 40,
    averageFee: 50,
    lastSync: "2025-06-01T15:45:00",
    integrationMethod: "API Integration",
  },
]

export function ApplicationSourceTracker() {
  const [statusFilter, setStatusFilter] = useState("all")
  const [sourceFilter, setSourceFilter] = useState("all")

  // Filter applications based on status and source
  const filteredApplications = applications.filter((app) => {
    const matchesStatus = statusFilter === "all" || app.status.toLowerCase() === statusFilter.toLowerCase()
    const matchesSource = sourceFilter === "all" || app.source.name === sourceFilter
    return matchesStatus && matchesSource
  })

  // Format date for display
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "N/A"
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })
  }

  // Calculate statistics
  const calculateSourceStats = () => {
    const stats = {
      total: applications.length,
      bySource: {} as Record<string, number>,
      byStatus: {
        submitted: applications.filter((app) => app.status === "Submitted").length,
        inProgress: applications.filter((app) => app.status === "In Progress").length,
        accepted: applications.filter((app) => app.status === "Accepted").length,
        rejected: applications.filter((app) => app.status === "Rejected").length,
      },
      byImportMethod: {
        api: applications.filter((app) => app.source.importMethod === "API Integration").length,
        scraping: applications.filter((app) => app.source.importMethod === "Web Scraping").length,
        manual: applications.filter((app) => app.source.importMethod === "Manual Entry").length,
      },
    }

    // Count by source
    applications.forEach((app) => {
      const sourceName = app.source.name
      stats.bySource[sourceName] = (stats.bySource[sourceName] || 0) + 1
    })

    return stats
  }

  const stats = calculateSourceStats()

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Application Source Tracker</h2>
          <p className="text-muted-foreground">
            Track where your applications come from and manage your opportunities across platforms.
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">From {Object.keys(stats.bySource).length} platforms</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Acceptance Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {((stats.byStatus.accepted / (stats.byStatus.accepted + stats.byStatus.rejected)) * 100).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              {stats.byStatus.accepted} accepted of {stats.byStatus.accepted + stats.byStatus.rejected} completed
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Top Platform</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Object.entries(stats.bySource).sort((a, b) => b[1] - a[1])[0][0]}</div>
            <p className="text-xs text-muted-foreground">
              {Object.entries(stats.bySource).sort((a, b) => b[1] - a[1])[0][1]} applications
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Import Methods</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className="flex-1">
                <div className="flex justify-between text-xs mb-1">
                  <span>API</span>
                  <span>{((stats.byImportMethod.api / stats.total) * 100).toFixed(0)}%</span>
                </div>
                <Progress value={(stats.byImportMethod.api / stats.total) * 100} className="h-1" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between text-xs mb-1">
                  <span>Scraping</span>
                  <span>{((stats.byImportMethod.scraping / stats.total) * 100).toFixed(0)}%</span>
                </div>
                <Progress value={(stats.byImportMethod.scraping / stats.total) * 100} className="h-1" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between text-xs mb-1">
                  <span>Manual</span>
                  <span>{((stats.byImportMethod.manual / stats.total) * 100).toFixed(0)}%</span>
                </div>
                <Progress value={(stats.byImportMethod.manual / stats.total) * 100} className="h-1" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="applications">
        <TabsList>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="sources">Source Platforms</TabsTrigger>
          <TabsTrigger value="analytics">Source Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="applications" className="space-y-4 mt-4">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="submitted">Submitted</SelectItem>
                <SelectItem value="in progress">In Progress</SelectItem>
                <SelectItem value="accepted">Accepted</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sourceFilter} onValueChange={setSourceFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by source" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sources</SelectItem>
                {sourcePlatforms.map((platform) => (
                  <SelectItem key={platform.id} value={platform.name}>
                    {platform.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Application</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Fee</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredApplications.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{app.title}</div>
                        <div className="text-sm text-muted-foreground">{app.organization}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger>
                              <Badge variant="outline" className="flex items-center gap-1">
                                {app.source.name}
                                <Info className="h-3 w-3 text-muted-foreground" />
                              </Badge>
                            </TooltipTrigger>
                            <TooltipContent className="w-80">
                              <div className="space-y-2">
                                <div className="font-medium">Source Details</div>
                                <div className="text-xs space-y-1">
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Platform:</span>
                                    <span>{app.source.name}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Import Method:</span>
                                    <span>{app.source.importMethod}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Import Date:</span>
                                    <span>{formatDate(app.source.importDate)}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Original ID:</span>
                                    <span>{app.source.originalId || "N/A"}</span>
                                  </div>
                                </div>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          app.status === "Accepted"
                            ? "bg-green-100 text-green-800"
                            : app.status === "Rejected"
                              ? "bg-red-100 text-red-800"
                              : app.status === "Submitted"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-yellow-100 text-yellow-800"
                        }
                      >
                        {app.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatDate(app.deadline)}</TableCell>
                    <TableCell>{app.fee === 0 ? "Free" : `$${app.fee}`}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" asChild>
                        <a href="#" className="flex items-center">
                          View
                          <ArrowUpRight className="ml-1 h-3 w-3" />
                        </a>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="sources" className="space-y-4 mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {sourcePlatforms.map((platform) => (
              <Card key={platform.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle>{platform.name}</CardTitle>
                    <Badge variant="outline">{platform.integrationMethod}</Badge>
                  </div>
                  <CardDescription>
                    <a href={platform.url} target="_blank" rel="noopener noreferrer" className="flex items-center">
                      {platform.url.replace(/(^\w+:|^)\/\//, "")}
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="text-xs text-muted-foreground">Applications</div>
                        <div className="font-medium">{platform.applicationCount}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Success Rate</div>
                        <div className="font-medium">{platform.successRate}%</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Average Fee</div>
                        <div className="font-medium">${platform.averageFee}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Last Sync</div>
                        <div className="font-medium">
                          {new Date(platform.lastSync).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="pt-2">
                  <div className="flex justify-between w-full">
                    <Button variant="outline" size="sm">
                      <Clock className="mr-2 h-4 w-4" />
                      Sync Now
                    </Button>
                    <Button size="sm">
                      <Tag className="mr-2 h-4 w-4" />
                      View Applications
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4 mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Applications by Source</CardTitle>
                <CardDescription>Distribution of applications across platforms</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(stats.bySource)
                    .sort((a, b) => b[1] - a[1])
                    .map(([source, count]) => (
                      <div key={source} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>{source}</span>
                          <span>
                            {count} ({((count / stats.total) * 100).toFixed(1)}%)
                          </span>
                        </div>
                        <Progress value={(count / stats.total) * 100} className="h-2" />
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Success Rate by Source</CardTitle>
                <CardDescription>Acceptance rates across different platforms</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sourcePlatforms
                    .sort((a, b) => b.successRate - a.successRate)
                    .map((platform) => (
                      <div key={platform.id} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>{platform.name}</span>
                          <span>{platform.successRate}%</span>
                        </div>
                        <Progress
                          value={platform.successRate}
                          className={`h-2 ${
                            platform.successRate > 30
                              ? "bg-green-600"
                              : platform.successRate > 10
                                ? "bg-yellow-600"
                                : "bg-red-600"
                          }`}
                        />
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Import Methods Comparison</CardTitle>
                <CardDescription>Effectiveness of different import methods</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Import Method</TableHead>
                      <TableHead>Applications</TableHead>
                      <TableHead>Platforms</TableHead>
                      <TableHead>Avg. Success Rate</TableHead>
                      <TableHead>Data Accuracy</TableHead>
                      <TableHead>Reliability</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">API Integration</TableCell>
                      <TableCell>{stats.byImportMethod.api}</TableCell>
                      <TableCell>
                        {sourcePlatforms.filter((p) => p.integrationMethod === "API Integration").length}
                      </TableCell>
                      <TableCell>
                        {(
                          sourcePlatforms
                            .filter((p) => p.integrationMethod === "API Integration")
                            .reduce((sum, p) => sum + p.successRate, 0) /
                          sourcePlatforms.filter((p) => p.integrationMethod === "API Integration").length
                        ).toFixed(1)}
                        %
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">High</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">High</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Web Scraping</TableCell>
                      <TableCell>{stats.byImportMethod.scraping}</TableCell>
                      <TableCell>
                        {sourcePlatforms.filter((p) => p.integrationMethod === "Web Scraping").length}
                      </TableCell>
                      <TableCell>
                        {(
                          sourcePlatforms
                            .filter((p) => p.integrationMethod === "Web Scraping")
                            .reduce((sum, p) => sum + p.successRate, 0) /
                          sourcePlatforms.filter((p) => p.integrationMethod === "Web Scraping").length
                        ).toFixed(1)}
                        %
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-yellow-100 text-yellow-800">Medium</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-yellow-100 text-yellow-800">Medium</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Manual Entry</TableCell>
                      <TableCell>{stats.byImportMethod.manual}</TableCell>
                      <TableCell>N/A</TableCell>
                      <TableCell>
                        {applications.filter((a) => a.source.importMethod === "Manual Entry").length > 0
                          ? (
                              (applications.filter(
                                (a) => a.source.importMethod === "Manual Entry" && a.status === "Accepted",
                              ).length /
                                applications.filter(
                                  (a) =>
                                    a.source.importMethod === "Manual Entry" &&
                                    (a.status === "Accepted" || a.status === "Rejected"),
                                ).length) *
                              100
                            ).toFixed(1)
                          : "0.0"}
                        %
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-red-100 text-red-800">Variable</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">High</Badge>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
