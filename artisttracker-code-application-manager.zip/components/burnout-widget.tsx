import { BatteryLow, BatteryMedium, BatteryFull, ArrowRight } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function BurnoutWidget() {
  // Sample burnout risk - in a real app, this would be calculated from mood data
  const burnoutRisk = 65

  const getBurnoutIcon = (risk: number) => {
    if (risk < 30) return <BatteryFull className="h-5 w-5 text-green-500" />
    if (risk < 70) return <BatteryMedium className="h-5 w-5 text-yellow-500" />
    return <BatteryLow className="h-5 w-5 text-red-500" />
  }

  const getBurnoutLevel = (risk: number) => {
    if (risk < 30) return "Low"
    if (risk < 70) return "Moderate"
    return "High"
  }

  const getBurnoutColor = (risk: number) => {
    if (risk < 30) return "text-green-500"
    if (risk < 70) return "text-yellow-500"
    return "text-red-500"
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Burnout Risk</CardTitle>
        <CardDescription>Based on your mood patterns</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2">
          {getBurnoutIcon(burnoutRisk)}
          <div className="flex-1">
            <div className="flex justify-between items-center mb-1">
              <span className={`text-sm font-medium ${getBurnoutColor(burnoutRisk)}`}>
                {getBurnoutLevel(burnoutRisk)}
              </span>
              <span className="text-sm text-muted-foreground">{burnoutRisk}%</span>
            </div>
            <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${
                  burnoutRisk < 30 ? "bg-green-500" : burnoutRisk < 70 ? "bg-yellow-500" : "bg-red-500"
                }`}
                style={{ width: `${burnoutRisk}%` }}
              />
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-1">
        <Button variant="ghost" size="sm" className="w-full" asChild>
          <Link href="/mood-tracker">
            View Details
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
