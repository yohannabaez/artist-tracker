"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  AlertCircle,
  BatteryCharging,
  BatteryFull,
  BatteryLow,
  BatteryMedium,
  CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Frown,
  Laugh,
  Meh,
  Smile,
} from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// Mood types
type MoodRating = 1 | 2 | 3 | 4 | 5
type MoodEntry = {
  date: Date
  rating: MoodRating
  notes: string
  energyLevel: number
  stressLevel: number
}

// Sample data for the chart
const moodHistoryData = [
  { date: "May 1", rating: 4, energy: 80, stress: 30 },
  { date: "May 2", rating: 4, energy: 75, stress: 35 },
  { date: "May 3", rating: 3, energy: 60, stress: 50 },
  { date: "May 4", rating: 3, energy: 65, stress: 45 },
  { date: "May 5", rating: 2, energy: 40, stress: 70 },
  { date: "May 6", rating: 2, energy: 35, stress: 75 },
  { date: "May 7", rating: 1, energy: 20, stress: 90 },
  { date: "May 8", rating: 2, energy: 30, stress: 80 },
  { date: "May 9", rating: 3, energy: 50, stress: 60 },
  { date: "May 10", rating: 3, energy: 55, stress: 55 },
  { date: "May 11", rating: 4, energy: 70, stress: 40 },
  { date: "May 12", rating: 5, energy: 85, stress: 25 },
  { date: "May 13", rating: 4, energy: 75, stress: 35 },
  { date: "May 14", rating: 4, energy: 70, stress: 40 },
]

// Sample mood entries for the calendar
const sampleMoodEntries: Record<string, MoodEntry> = {
  "2025-05-01": {
    date: new Date(2025, 4, 1),
    rating: 4,
    notes: "Productive day, finished two applications.",
    energyLevel: 80,
    stressLevel: 30,
  },
  "2025-05-05": {
    date: new Date(2025, 4, 5),
    rating: 2,
    notes: "Feeling overwhelmed with deadlines.",
    energyLevel: 40,
    stressLevel: 70,
  },
  "2025-05-07": {
    date: new Date(2025, 4, 7),
    rating: 1,
    notes: "Burnout warning. Too many rejections this week.",
    energyLevel: 20,
    stressLevel: 90,
  },
  "2025-05-12": {
    date: new Date(2025, 4, 12),
    rating: 5,
    notes: "Got accepted to the residency! Feeling great.",
    energyLevel: 85,
    stressLevel: 25,
  },
}

export function MoodTracker() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [currentMood, setCurrentMood] = useState<MoodRating | null>(null)
  const [energyLevel, setEnergyLevel] = useState(50)
  const [stressLevel, setStressLevel] = useState(50)
  const [notes, setNotes] = useState("")
  const [burnoutRisk, setBurnoutRisk] = useState(65) // Sample burnout risk percentage

  // Calculate burnout risk based on recent mood entries
  const getBurnoutRiskLevel = (risk: number) => {
    if (risk < 30) return "Low"
    if (risk < 70) return "Moderate"
    return "High"
  }

  const getBurnoutIcon = (risk: number) => {
    if (risk < 30) return <BatteryFull className="h-5 w-5 text-green-500" />
    if (risk < 70) return <BatteryMedium className="h-5 w-5 text-yellow-500" />
    return <BatteryLow className="h-5 w-5 text-red-500" />
  }

  // Get recommendations based on burnout risk
  const getRecommendations = (risk: number) => {
    if (risk < 30) {
      return [
        "You're doing well! This is a good time to take on new applications.",
        "Consider helping other artists with their applications.",
        "Document your current process for future reference.",
      ]
    }
    if (risk < 70) {
      return [
        "Consider spacing out your application deadlines more evenly.",
        "Take a day off between intensive application work.",
        "Focus on quality over quantity for upcoming opportunities.",
        "Schedule time for creative work between applications.",
      ]
    }
    return [
      "Warning: High burnout risk detected. Consider taking a break from applications for at least a week.",
      "Postpone non-urgent applications if possible.",
      "Schedule self-care activities daily.",
      "Reach out to your support network.",
      "Consider talking to a mental health professional.",
    ]
  }

  // Get mood icon based on rating
  const getMoodIcon = (rating: MoodRating) => {
    switch (rating) {
      case 1:
        return <Frown className="h-8 w-8" />
      case 2:
        return <Meh className="h-8 w-8" />
      case 3:
        return <Smile className="h-8 w-8" />
      case 4:
        return <Smile className="h-8 w-8" />
      case 5:
        return <Laugh className="h-8 w-8" />
    }
  }

  // Get mood color based on rating
  const getMoodColor = (rating: MoodRating) => {
    switch (rating) {
      case 1:
        return "text-red-500"
      case 2:
        return "text-orange-500"
      case 3:
        return "text-yellow-500"
      case 4:
        return "text-green-500"
      case 5:
        return "text-emerald-500"
    }
  }

  // Get mood label based on rating
  const getMoodLabel = (rating: MoodRating) => {
    switch (rating) {
      case 1:
        return "Struggling"
      case 2:
        return "Challenging"
      case 3:
        return "Okay"
      case 4:
        return "Good"
      case 5:
        return "Excellent"
    }
  }

  // Get background color for calendar day based on mood
  const getDayBackgroundColor = (date: Date) => {
    const dateString = date.toISOString().split("T")[0]
    const entry = sampleMoodEntries[dateString]
    if (!entry) return ""

    switch (entry.rating) {
      case 1:
        return "bg-red-100"
      case 2:
        return "bg-orange-100"
      case 3:
        return "bg-yellow-100"
      case 4:
        return "bg-green-100"
      case 5:
        return "bg-emerald-100"
    }
  }

  // Handle mood selection
  const handleMoodSelection = (rating: MoodRating) => {
    setCurrentMood(rating)
  }

  // Handle log submission
  const handleSubmitMoodLog = () => {
    // In a real app, this would save to the database
    console.log("Mood logged:", {
      date,
      rating: currentMood,
      notes,
      energyLevel,
      stressLevel,
    })

    // Reset form
    setCurrentMood(null)
    setNotes("")
    setEnergyLevel(50)
    setStressLevel(50)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Mood Tracker & Burnout Meter</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button>Log Today's Mood</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>How are you feeling today?</DialogTitle>
              <DialogDescription>
                Track your mood to help manage your application workload and prevent burnout.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="flex justify-between items-center">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <Button
                    key={rating}
                    variant={currentMood === rating ? "default" : "outline"}
                    size="lg"
                    className={`flex-col h-auto py-3 ${currentMood === rating ? getMoodColor(rating as MoodRating) : ""}`}
                    onClick={() => handleMoodSelection(rating as MoodRating)}
                  >
                    <div className="mb-1">{getMoodIcon(rating as MoodRating)}</div>
                    <span className="text-xs">{getMoodLabel(rating as MoodRating)}</span>
                  </Button>
                ))}
              </div>

              <div className="space-y-2">
                <Label htmlFor="energy">Energy Level</Label>
                <div className="flex items-center gap-2">
                  <BatteryLow className="h-4 w-4 text-muted-foreground" />
                  <Progress value={energyLevel} className="flex-1" />
                  <BatteryFull className="h-4 w-4 text-muted-foreground" />
                </div>
                <input
                  type="range"
                  id="energy"
                  min="0"
                  max="100"
                  value={energyLevel}
                  onChange={(e) => setEnergyLevel(Number.parseInt(e.target.value))}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stress">Stress Level</Label>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Low</span>
                  <Progress value={stressLevel} className="flex-1" />
                  <span className="text-xs text-muted-foreground">High</span>
                </div>
                <input
                  type="range"
                  id="stress"
                  min="0"
                  max="100"
                  value={stressLevel}
                  onChange={(e) => setStressLevel(Number.parseInt(e.target.value))}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes (optional)</Label>
                <Textarea
                  id="notes"
                  placeholder="How are you feeling about your applications today?"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleSubmitMoodLog} disabled={!currentMood}>
                Log Mood
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Mood History</CardTitle>
            <CardDescription>Track your mood patterns over time</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="chart">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="chart">Chart View</TabsTrigger>
                <TabsTrigger value="calendar">Calendar View</TabsTrigger>
              </TabsList>
              <TabsContent value="chart" className="space-y-4">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={moodHistoryData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="rating" stroke="#8884d8" name="Mood" />
                      <Line type="monotone" dataKey="energy" stroke="#82ca9d" name="Energy" />
                      <Line type="monotone" dataKey="stress" stroke="#ff7300" name="Stress" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <div className="mr-1 h-3 w-3 rounded-full bg-[#8884d8]" />
                    <span>Mood</span>
                  </div>
                  <div className="flex items-center">
                    <div className="mr-1 h-3 w-3 rounded-full bg-[#82ca9d]" />
                    <span>Energy</span>
                  </div>
                  <div className="flex items-center">
                    <div className="mr-1 h-3 w-3 rounded-full bg-[#ff7300]" />
                    <span>Stress</span>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="calendar">
                <div className="flex justify-between items-center mb-2">
                  <Button variant="outline" size="sm">
                    <ChevronLeft className="h-4 w-4 mr-1" />
                    Previous Month
                  </Button>
                  <div className="font-medium">May 2025</div>
                  <Button variant="outline" size="sm">
                    Next Month
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                  modifiers={{
                    mood1: Object.values(sampleMoodEntries)
                      .filter((entry) => entry.rating === 1)
                      .map((entry) => entry.date),
                    mood2: Object.values(sampleMoodEntries)
                      .filter((entry) => entry.rating === 2)
                      .map((entry) => entry.date),
                    mood3: Object.values(sampleMoodEntries)
                      .filter((entry) => entry.rating === 3)
                      .map((entry) => entry.date),
                    mood4: Object.values(sampleMoodEntries)
                      .filter((entry) => entry.rating === 4)
                      .map((entry) => entry.date),
                    mood5: Object.values(sampleMoodEntries)
                      .filter((entry) => entry.rating === 5)
                      .map((entry) => entry.date),
                  }}
                  modifiersClassNames={{
                    mood1: "bg-red-100 text-red-900",
                    mood2: "bg-orange-100 text-orange-900",
                    mood3: "bg-yellow-100 text-yellow-900",
                    mood4: "bg-green-100 text-green-900",
                    mood5: "bg-emerald-100 text-emerald-900",
                  }}
                />
                <div className="mt-4 grid grid-cols-5 gap-2">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <div key={rating} className="flex items-center text-xs">
                      <div
                        className={`mr-1 h-3 w-3 rounded-full ${
                          rating === 1
                            ? "bg-red-500"
                            : rating === 2
                              ? "bg-orange-500"
                              : rating === 3
                                ? "bg-yellow-500"
                                : rating === 4
                                  ? "bg-green-500"
                                  : "bg-emerald-500"
                        }`}
                      />
                      <span>{getMoodLabel(rating as MoodRating)}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Burnout Risk</CardTitle>
            <CardDescription>Based on your recent mood patterns</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center">
              <div className="relative w-40 h-40">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle
                    className="text-muted stroke-current"
                    strokeWidth="10"
                    cx="50"
                    cy="50"
                    r="40"
                    fill="transparent"
                  />
                  <circle
                    className={`${
                      burnoutRisk < 30 ? "text-green-500" : burnoutRisk < 70 ? "text-yellow-500" : "text-red-500"
                    } stroke-current`}
                    strokeWidth="10"
                    strokeLinecap="round"
                    cx="50"
                    cy="50"
                    r="40"
                    fill="transparent"
                    strokeDasharray={`${burnoutRisk * 2.51} 251.2`}
                    transform="rotate(-90 50 50)"
                  />
                  <text
                    x="50"
                    y="50"
                    dominantBaseline="middle"
                    textAnchor="middle"
                    className="text-3xl font-bold"
                    fill="currentColor"
                  >
                    {burnoutRisk}%
                  </text>
                </svg>
              </div>
              <div className="mt-4 text-center">
                <div className="text-lg font-semibold flex items-center justify-center gap-2">
                  {getBurnoutIcon(burnoutRisk)}
                  <span>{getBurnoutRiskLevel(burnoutRisk)} Risk</span>
                </div>
              </div>
            </div>

            <Alert
              className={
                burnoutRisk < 30
                  ? "bg-green-50 border-green-200"
                  : burnoutRisk < 70
                    ? "bg-yellow-50 border-yellow-200"
                    : "bg-red-50 border-red-200"
              }
            >
              <AlertCircle
                className={
                  burnoutRisk < 30
                    ? "h-4 w-4 text-green-600"
                    : burnoutRisk < 70
                      ? "h-4 w-4 text-yellow-600"
                      : "h-4 w-4 text-red-600"
                }
              />
              <AlertTitle>
                {burnoutRisk < 30
                  ? "You're doing well!"
                  : burnoutRisk < 70
                    ? "Monitor your energy levels"
                    : "Warning: High burnout risk"}
              </AlertTitle>
              <AlertDescription>
                {burnoutRisk < 30
                  ? "Your mood patterns show good resilience."
                  : burnoutRisk < 70
                    ? "Consider taking more breaks between applications."
                    : "Take immediate action to reduce your application workload."}
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recommendations</CardTitle>
          <CardDescription>Based on your current burnout risk level</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <h3 className="font-medium">Application Pacing</h3>
                <ul className="space-y-1 text-sm list-disc pl-5">
                  {getRecommendations(burnoutRisk).map((rec, index) => (
                    <li key={index}>{rec}</li>
                  ))}
                </ul>
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">Wellness Resources</h3>
                <ul className="space-y-1 text-sm list-disc pl-5">
                  <li>5-minute meditation for creative focus</li>
                  <li>Artist burnout prevention guide</li>
                  <li>Creative community support groups</li>
                  <li>Journaling prompts for artists</li>
                </ul>
              </div>
            </div>

            <div className="pt-2">
              <h3 className="font-medium mb-2">Suggested Schedule Adjustments</h3>
              <div className="border rounded-md p-3 space-y-2">
                <div className="flex items-start gap-2">
                  <CalendarIcon className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Reschedule International Art Prize application</p>
                    <p className="text-xs text-muted-foreground">Move from May 15 to May 22 to create a buffer</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Clock className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Block creative recovery time</p>
                    <p className="text-xs text-muted-foreground">Add 3 days with no application work after May 20</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <BatteryCharging className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Schedule wellness activities</p>
                    <p className="text-xs text-muted-foreground">Add 30 minutes daily for the next week</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full">
            Apply Suggested Changes
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
