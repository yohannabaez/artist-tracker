"use client"

import { useState } from "react"
import { Search, Filter, ExternalLink, Calendar, DollarSign, MapPin, Tag } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"

// Sample opportunity data from various sources
const opportunities = [
  {
    id: "cafe-001",
    title: "Annual Juried Exhibition",
    organization: "National Art Gallery",
    source: "CaFÉ",
    sourceUrl: "https://artist.callforentry.org",
    type: "Exhibition",
    location: "Denver, CO",
    deadline: "2025-06-15",
    fee: 35,
    eligibility: "National",
    medium: ["Painting", "Sculpture", "Photography"],
    description:
      "A prestigious annual exhibition showcasing contemporary works across various mediums. Selected artists will have their work displayed in the main gallery for three months.",
    url: "https://artist.callforentry.org/festivals_unique_info.php?ID=12345",
    tags: ["Juried", "Exhibition", "Contemporary"],
  },
  {
    id: "ru-001",
    title: "Emerging Artists Residency Program",
    organization: "Residency Unlimited",
    source: "Residency Unlimited",
    sourceUrl: "https://residencyunlimited.org",
    type: "Residency",
    location: "New York, NY",
    deadline: "2025-07-30",
    fee: 0,
    eligibility: "International",
    medium: ["All Media"],
    description:
      "A three-month residency program for emerging artists, providing studio space, mentorship, and exhibition opportunities in the heart of New York City.",
    url: "https://residencyunlimited.org/programs/emerging-artist-residency-2025/",
    tags: ["Residency", "Emerging Artists", "Mentorship"],
  },
  {
    id: "rivet-001",
    title: "Digital Art Fellowship",
    organization: "Rivet Contemporary Art Center",
    source: "Rivet",
    sourceUrl: "https://rivet.es",
    type: "Fellowship",
    location: "Barcelona, Spain",
    deadline: "2025-08-10",
    fee: 20,
    eligibility: "International",
    medium: ["Digital Art", "New Media", "Interactive"],
    description:
      "A six-month fellowship for artists working with digital technologies. Fellows receive a stipend, studio space, and technical support for creating innovative digital artworks.",
    url: "https://rivet.es/calls/digital-art-fellowship-2025",
    tags: ["Digital", "Fellowship", "Technology"],
  },
  {
    id: "china-001",
    title: "Red Gate Residency",
    organization: "Red Gate Gallery",
    source: "China Residencies",
    sourceUrl: "https://www.chinaresidencies.com",
    type: "Residency",
    location: "Beijing, China",
    deadline: "2025-09-01",
    fee: 50,
    eligibility: "International",
    medium: ["All Media"],
    description:
      "A two-month residency in Beijing, providing international artists with studio space, accommodation, and cultural exchange opportunities in one of China's most vibrant art scenes.",
    url: "https://www.chinaresidencies.com/residencies/red-gate-residency",
    tags: ["International", "Cultural Exchange", "Asia"],
  },
  {
    id: "cc-001",
    title: "Creative Capital Grant",
    organization: "Creative Capital",
    source: "Creative Capital",
    sourceUrl: "https://creative-capital.org",
    type: "Grant",
    location: "United States",
    deadline: "2025-02-28",
    fee: 0,
    eligibility: "US-based artists",
    medium: ["All Media"],
    description:
      "Up to $50,000 in funding for innovative projects in all disciplines. Creative Capital provides funding, counsel, and career development services to artists pursuing ambitious projects.",
    url: "https://creative-capital.org/apply/",
    tags: ["Grant", "Funding", "Career Development"],
  },
  {
    id: "cafe-002",
    title: "Public Art Commission",
    organization: "City Arts Commission",
    source: "CaFÉ",
    sourceUrl: "https://artist.callforentry.org",
    type: "Commission",
    location: "Portland, OR",
    deadline: "2025-05-20",
    fee: 0,
    eligibility: "National",
    medium: ["Sculpture", "Installation", "Mixed Media"],
    description:
      "Commission for a large-scale public artwork for the new downtown plaza. Budget of $100,000 includes design, fabrication, and installation.",
    url: "https://artist.callforentry.org/festivals_unique_info.php?ID=23456",
    tags: ["Public Art", "Commission", "Large Scale"],
  },
  {
    id: "ru-002",
    title: "Social Practice Residency",
    organization: "Community Arts Initiative",
    source: "Residency Unlimited",
    sourceUrl: "https://residencyunlimited.org",
    type: "Residency",
    location: "Chicago, IL",
    deadline: "2025-04-15",
    fee: 25,
    eligibility: "National",
    medium: ["Social Practice", "Community Engagement"],
    description:
      "A residency focused on socially engaged art practices. Artists work directly with community organizations to develop projects that address local social issues.",
    url: "https://residencyunlimited.org/programs/social-practice-residency-2025/",
    tags: ["Social Practice", "Community", "Engagement"],
  },
  {
    id: "rivet-002",
    title: "Experimental Film Festival",
    organization: "Rivet Film Collective",
    source: "Rivet",
    sourceUrl: "https://rivet.es",
    type: "Festival",
    location: "Madrid, Spain",
    deadline: "2025-07-01",
    fee: 30,
    eligibility: "International",
    medium: ["Film", "Video", "Animation"],
    description:
      "Annual festival showcasing experimental and avant-garde film and video works. Selected works will be screened at various venues throughout Madrid.",
    url: "https://rivet.es/calls/experimental-film-festival-2025",
    tags: ["Film", "Festival", "Experimental"],
  },
]

// Source platforms
const sources = [
  { id: "cafe", name: "CaFÉ", url: "https://artist.callforentry.org" },
  { id: "ru", name: "Residency Unlimited", url: "https://residencyunlimited.org" },
  { id: "rivet", name: "Rivet", url: "https://rivet.es" },
  { id: "china", name: "China Residencies", url: "https://www.chinaresidencies.com" },
  { id: "cc", name: "Creative Capital", url: "https://creative-capital.org" },
]

// Opportunity types
const opportunityTypes = ["Exhibition", "Residency", "Fellowship", "Grant", "Commission", "Festival", "Competition"]

// Media types
const mediaTypes = [
  "Painting",
  "Sculpture",
  "Photography",
  "Digital Art",
  "New Media",
  "Film/Video",
  "Installation",
  "Performance",
  "Social Practice",
  "Mixed Media",
  "All Media",
]

export function OpportunitySources() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSources, setSelectedSources] = useState<string[]>([])
  const [selectedTypes, setSelectedTypes] = useState<string[]>([])
  const [selectedMedia, setSelectedMedia] = useState<string[]>([])
  const [hasFee, setHasFee] = useState<string>("all")
  const [selectedOpportunity, setSelectedOpportunity] = useState<any>(null)

  // Filter opportunities based on search and filters
  const filteredOpportunities = opportunities.filter((opp) => {
    // Search query filter
    const matchesSearch =
      searchQuery === "" ||
      opp.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      opp.organization.toLowerCase().includes(searchQuery.toLowerCase()) ||
      opp.description.toLowerCase().includes(searchQuery.toLowerCase())

    // Source filter
    const matchesSource = selectedSources.length === 0 || selectedSources.includes(opp.source)

    // Type filter
    const matchesType = selectedTypes.length === 0 || selectedTypes.includes(opp.type)

    // Media filter
    const matchesMedia =
      selectedMedia.length === 0 || opp.medium.some((m) => selectedMedia.includes(m) || m === "All Media")

    // Fee filter
    const matchesFee = hasFee === "all" || (hasFee === "free" && opp.fee === 0) || (hasFee === "paid" && opp.fee > 0)

    return matchesSearch && matchesSource && matchesType && matchesMedia && matchesFee
  })

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })
  }

  // Calculate days until deadline
  const getDaysUntilDeadline = (dateString: string) => {
    const deadline = new Date(dateString)
    const today = new Date()
    const diffTime = deadline.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  // Get badge color based on days until deadline
  const getDeadlineBadgeColor = (days: number) => {
    if (days < 0) return "bg-gray-100 text-gray-800"
    if (days < 7) return "bg-red-100 text-red-800"
    if (days < 30) return "bg-orange-100 text-orange-800"
    if (days < 60) return "bg-yellow-100 text-yellow-800"
    return "bg-green-100 text-green-800"
  }

  // Get deadline text based on days until deadline
  const getDeadlineText = (days: number) => {
    if (days < 0) return "Closed"
    if (days === 0) return "Due today"
    if (days === 1) return "1 day left"
    return `${days} days left`
  }

  // Toggle source selection
  const toggleSource = (source: string) => {
    setSelectedSources((prev) => (prev.includes(source) ? prev.filter((s) => s !== source) : [...prev, source]))
  }

  // Toggle type selection
  const toggleType = (type: string) => {
    setSelectedTypes((prev) => (prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]))
  }

  // Toggle media selection
  const toggleMedia = (media: string) => {
    setSelectedMedia((prev) => (prev.includes(media) ? prev.filter((m) => m !== media) : [...prev, media]))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <h2 className="text-2xl font-bold tracking-tight">Opportunity Explorer</h2>
        <p className="text-muted-foreground">
          Browse opportunities from multiple platforms in one place. Filter by type, deadline, and more.
        </p>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search opportunities..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filters
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Filter Opportunities</DialogTitle>
                <DialogDescription>
                  Narrow down opportunities based on your preferences and requirements.
                </DialogDescription>
              </DialogHeader>
              <ScrollArea className="h-[60vh] pr-4">
                <div className="space-y-6 py-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Sources</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {sources.map((source) => (
                        <div key={source.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`source-${source.id}`}
                            checked={selectedSources.includes(source.name)}
                            onCheckedChange={() => toggleSource(source.name)}
                          />
                          <Label htmlFor={`source-${source.id}`} className="text-sm">
                            {source.name}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Opportunity Type</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {opportunityTypes.map((type) => (
                        <div key={type} className="flex items-center space-x-2">
                          <Checkbox
                            id={`type-${type}`}
                            checked={selectedTypes.includes(type)}
                            onCheckedChange={() => toggleType(type)}
                          />
                          <Label htmlFor={`type-${type}`} className="text-sm">
                            {type}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Medium</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {mediaTypes.map((media) => (
                        <div key={media} className="flex items-center space-x-2">
                          <Checkbox
                            id={`media-${media}`}
                            checked={selectedMedia.includes(media)}
                            onCheckedChange={() => toggleMedia(media)}
                          />
                          <Label htmlFor={`media-${media}`} className="text-sm">
                            {media}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Application Fee</h3>
                    <div className="flex flex-col space-y-2">
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="fee-all"
                          name="fee"
                          value="all"
                          checked={hasFee === "all"}
                          onChange={() => setHasFee("all")}
                          className="h-4 w-4"
                        />
                        <Label htmlFor="fee-all" className="text-sm">
                          All opportunities
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="fee-free"
                          name="fee"
                          value="free"
                          checked={hasFee === "free"}
                          onChange={() => setHasFee("free")}
                          className="h-4 w-4"
                        />
                        <Label htmlFor="fee-free" className="text-sm">
                          No application fee
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="fee-paid"
                          name="fee"
                          value="paid"
                          checked={hasFee === "paid"}
                          onChange={() => setHasFee("paid")}
                          className="h-4 w-4"
                        />
                        <Label htmlFor="fee-paid" className="text-sm">
                          Has application fee
                        </Label>
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollArea>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedSources([])
                    setSelectedTypes([])
                    setSelectedMedia([])
                    setHasFee("all")
                  }}
                >
                  Reset Filters
                </Button>
                <Button type="submit">Apply Filters</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Select defaultValue="deadline">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="deadline">Deadline (Soonest)</SelectItem>
              <SelectItem value="deadline-latest">Deadline (Latest)</SelectItem>
              <SelectItem value="title">Title (A-Z)</SelectItem>
              <SelectItem value="fee-low">Fee (Low to High)</SelectItem>
              <SelectItem value="fee-high">Fee (High to Low)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="grid">
        <div className="flex justify-between items-center mb-4">
          <div className="text-sm text-muted-foreground">{filteredOpportunities.length} opportunities found</div>
          <TabsList>
            <TabsTrigger value="grid">Grid View</TabsTrigger>
            <TabsTrigger value="list">List View</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="grid" className="mt-0">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredOpportunities.map((opportunity) => {
              const daysUntilDeadline = getDaysUntilDeadline(opportunity.deadline)
              const deadlineBadgeColor = getDeadlineBadgeColor(daysUntilDeadline)
              const deadlineText = getDeadlineText(daysUntilDeadline)

              return (
                <Card key={opportunity.id} className="flex flex-col">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <Badge variant="outline" className="mb-2">
                        {opportunity.source}
                      </Badge>
                      <Badge variant="outline" className={deadlineBadgeColor}>
                        {deadlineText}
                      </Badge>
                    </div>
                    <CardTitle className="line-clamp-1">{opportunity.title}</CardTitle>
                    <CardDescription>{opportunity.organization}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2 flex-grow">
                    <div className="space-y-2">
                      <div className="flex items-center text-sm">
                        <Tag className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>{opportunity.type}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>{opportunity.location}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>Deadline: {formatDate(opportunity.deadline)}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>Application Fee: {opportunity.fee === 0 ? "None" : `$${opportunity.fee}`}</span>
                      </div>
                    </div>
                    <div className="mt-3">
                      <p className="text-sm text-muted-foreground line-clamp-2">{opportunity.description}</p>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-3">
                      {opportunity.tags.map((tag: string) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2">
                    <div className="flex justify-between w-full">
                      <Button variant="outline" size="sm" onClick={() => setSelectedOpportunity(opportunity)}>
                        View Details
                      </Button>
                      <Button size="sm" asChild>
                        <a href={opportunity.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Apply
                        </a>
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="list" className="mt-0">
          <div className="space-y-2">
            {filteredOpportunities.map((opportunity) => {
              const daysUntilDeadline = getDaysUntilDeadline(opportunity.deadline)
              const deadlineBadgeColor = getDeadlineBadgeColor(daysUntilDeadline)
              const deadlineText = getDeadlineText(daysUntilDeadline)

              return (
                <Card key={opportunity.id}>
                  <div className="p-4 flex flex-col md:flex-row gap-4">
                    <div className="flex-grow">
                      <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{opportunity.source}</Badge>
                          <h3 className="font-semibold">{opportunity.title}</h3>
                        </div>
                        <Badge variant="outline" className={`${deadlineBadgeColor} mt-1 md:mt-0`}>
                          {deadlineText}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{opportunity.organization}</p>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm mb-2">
                        <div className="flex items-center">
                          <Tag className="h-4 w-4 mr-1 text-muted-foreground" />
                          <span>{opportunity.type}</span>
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
                          <span>{opportunity.location}</span>
                        </div>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                          <span>{formatDate(opportunity.deadline)}</span>
                        </div>
                        <div className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-1 text-muted-foreground" />
                          <span>{opportunity.fee === 0 ? "No Fee" : `$${opportunity.fee}`}</span>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {opportunity.tags.map((tag: string) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex md:flex-col gap-2 justify-end">
                      <Button variant="outline" size="sm" onClick={() => setSelectedOpportunity(opportunity)}>
                        Details
                      </Button>
                      <Button size="sm" asChild>
                        <a href={opportunity.url} target="_blank" rel="noopener noreferrer">
                          Apply
                        </a>
                      </Button>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Opportunity Details Dialog */}
      {selectedOpportunity && (
        <Dialog open={!!selectedOpportunity} onOpenChange={() => setSelectedOpportunity(null)}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>{selectedOpportunity.title}</DialogTitle>
              <DialogDescription>{selectedOpportunity.organization}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-1">Source</h4>
                  <p className="text-sm flex items-center">
                    <ExternalLink className="h-4 w-4 mr-1 text-muted-foreground" />
                    <a
                      href={selectedOpportunity.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      {selectedOpportunity.source}
                    </a>
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Type</h4>
                  <p className="text-sm">{selectedOpportunity.type}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Location</h4>
                  <p className="text-sm">{selectedOpportunity.location}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Deadline</h4>
                  <p className="text-sm">{formatDate(selectedOpportunity.deadline)}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Application Fee</h4>
                  <p className="text-sm">{selectedOpportunity.fee === 0 ? "No fee" : `$${selectedOpportunity.fee}`}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Eligibility</h4>
                  <p className="text-sm">{selectedOpportunity.eligibility}</p>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-1">Media</h4>
                <div className="flex flex-wrap gap-1">
                  {selectedOpportunity.medium.map((m: string) => (
                    <Badge key={m} variant="outline" className="text-xs">
                      {m}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-1">Description</h4>
                <p className="text-sm">{selectedOpportunity.description}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-1">Tags</h4>
                <div className="flex flex-wrap gap-1">
                  {selectedOpportunity.tags.map((tag: string) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setSelectedOpportunity(null)}>
                Close
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" asChild>
                  <a href="#" onClick={(e) => e.preventDefault()}>
                    Save to Favorites
                  </a>
                </Button>
                <Button asChild>
                  <a href={selectedOpportunity.url} target="_blank" rel="noopener noreferrer">
                    Apply Now
                  </a>
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
