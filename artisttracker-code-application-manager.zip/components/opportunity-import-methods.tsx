"use client"

import type React from "react"

import { useState } from "react"
import {
  Link,
  Upload,
  FileSpreadsheet,
  Globe,
  Check,
  X,
  AlertCircle,
  ArrowRight,
  Download,
  FileUp,
  Loader2,
  Play,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"

// Sample data for recently imported opportunities
const recentImports = [
  {
    id: "imp-001",
    source: "URL Import",
    title: "Emerging Artist Grant",
    organization: "National Arts Foundation",
    importDate: "2025-06-10T14:30:00",
    status: "Success",
    url: "https://nationalartsfoundation.org/grants/emerging-artist-2025",
  },
  {
    id: "imp-002",
    source: "Excel Import",
    title: "Multiple Opportunities (15)",
    organization: "Various",
    importDate: "2025-06-08T10:15:00",
    status: "Success",
    url: null,
  },
  {
    id: "imp-003",
    source: "URL Import",
    title: "Summer Residency Program",
    organization: "Mountain Creative Retreat",
    importDate: "2025-06-05T16:45:00",
    status: "Success",
    url: "https://mountaincreativeretreat.org/residency/summer-2025",
  },
  {
    id: "imp-004",
    source: "URL Import",
    title: "Unknown Opportunity",
    organization: "Unknown",
    importDate: "2025-06-03T09:20:00",
    status: "Failed",
    url: "https://example.com/invalid-opportunity",
  },
  {
    id: "imp-005",
    source: "Excel Import",
    title: "Film Festivals (8)",
    organization: "Various",
    importDate: "2025-06-01T11:30:00",
    status: "Partial Success",
    url: null,
  },
]

// Sample Excel preview data
const excelPreviewData = [
  {
    title: "Documentary Film Grant",
    organization: "Truth in Cinema Foundation",
    type: "Grant",
    deadline: "2025-08-30",
    location: "United States",
    fee: "25",
    url: "https://truthincinema.org/grants/documentary",
    categories: "Documentary, Non-Fiction",
    description: "A grant program supporting documentary filmmakers working on socially relevant projects.",
  },
  {
    title: "Short Film Competition",
    organization: "New Voices Cinema",
    type: "Competition",
    deadline: "2025-06-15",
    location: "Online",
    fee: "20",
    url: "https://newvoicescinema.org/shorts-competition",
    categories: "Narrative Short, Experimental, Animation",
    description: "A competition for short films under 20 minutes.",
  },
  {
    title: "Emerging Writers Fellowship",
    organization: "Industry Access",
    type: "Fellowship",
    deadline: "2025-06-30",
    location: "Los Angeles, CA",
    fee: "40",
    url: "https://industryaccess.org/fellowship",
    categories: "Feature Screenplay, TV Pilot",
    description: "A fellowship program for emerging screenwriters.",
  },
]

// Field mapping options
const fieldMappingOptions = [
  { value: "title", label: "Title" },
  { value: "organization", label: "Organization" },
  { value: "type", label: "Type" },
  { value: "deadline", label: "Deadline" },
  { value: "location", label: "Location" },
  { value: "fee", label: "Fee" },
  { value: "url", label: "URL" },
  { value: "categories", label: "Categories" },
  { value: "description", label: "Description" },
  { value: "eligibility", label: "Eligibility" },
  { value: "requirements", label: "Requirements" },
  { value: "notes", label: "Notes" },
  { value: "ignore", label: "Ignore this column" },
]

export function OpportunityImportMethods() {
  const [activeTab, setActiveTab] = useState("url")
  const [urlInput, setUrlInput] = useState("")
  const [urlNotes, setUrlNotes] = useState("")
  const [isUrlProcessing, setIsUrlProcessing] = useState(false)
  const [urlProcessingProgress, setUrlProcessingProgress] = useState(0)
  const [urlProcessingResult, setUrlProcessingResult] = useState<null | { success: boolean; message: string }>(null)
  const [urlPreview, setUrlPreview] = useState<any>(null)

  const [isFileUploaded, setIsFileUploaded] = useState(false)
  const [fileName, setFileName] = useState("")
  const [isExcelProcessing, setIsExcelProcessing] = useState(false)
  const [excelProcessingProgress, setExcelProcessingProgress] = useState(0)
  const [showExcelPreview, setShowExcelPreview] = useState(false)
  const [fieldMapping, setFieldMapping] = useState<Record<string, string>>({
    0: "title",
    1: "organization",
    2: "type",
    3: "deadline",
    4: "location",
    5: "fee",
    6: "url",
    7: "categories",
    8: "description",
  })

  const [showImportHistory, setShowImportHistory] = useState(false)
  const [templateDownloading, setTemplateDownloading] = useState(false)

  // Handle URL submission
  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!urlInput) return

    setIsUrlProcessing(true)
    setUrlProcessingProgress(0)
    setUrlProcessingResult(null)

    // Simulate URL processing with progress
    const interval = setInterval(() => {
      setUrlProcessingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUrlProcessing(false)

          // Simulate success or failure based on URL
          if (urlInput.includes("invalid")) {
            setUrlProcessingResult({
              success: false,
              message:
                "Could not extract opportunity information from this URL. Please check the URL or try manual entry.",
            })
            setUrlPreview(null)
          } else {
            setUrlProcessingResult({
              success: true,
              message: "Successfully extracted opportunity information!",
            })
            // Set sample preview data
            setUrlPreview({
              title: "Summer Residency Program 2025",
              organization: "Mountain Creative Retreat",
              type: "Residency",
              deadline: "2025-09-15",
              location: "Colorado, USA",
              fee: 35,
              categories: ["Visual Arts", "Writing", "Interdisciplinary"],
              description:
                "A two-month summer residency with studio space and housing in the beautiful Rocky Mountains.",
              eligibility: "Open to artists at all career stages, international applicants welcome.",
              requirements: [
                "CV/Resume",
                "Artist statement",
                "Work samples (10 images or 5 minutes of video)",
                "Project proposal",
              ],
            })
          }
          return 100
        }
        return prev + 10
      })
    }, 300)
  }

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setFileName(file.name)
    setIsFileUploaded(true)
  }

  // Process Excel file
  const processExcelFile = () => {
    if (!isFileUploaded) return

    setIsExcelProcessing(true)
    setExcelProcessingProgress(0)

    // Simulate processing with progress
    const interval = setInterval(() => {
      setExcelProcessingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsExcelProcessing(false)
          setShowExcelPreview(true)
          return 100
        }
        return prev + 10
      })
    }, 200)
  }

  // Handle field mapping change
  const handleFieldMappingChange = (columnIndex: number, value: string) => {
    setFieldMapping((prev) => ({
      ...prev,
      [columnIndex]: value,
    }))
  }

  // Import opportunities from Excel
  const importFromExcel = () => {
    setIsExcelProcessing(true)

    // Simulate import process
    setTimeout(() => {
      setIsExcelProcessing(false)
      setIsFileUploaded(false)
      setFileName("")
      setShowExcelPreview(false)

      // Show success message or redirect
      alert("Successfully imported 3 opportunities from Excel file!")
    }, 2000)
  }

  // Download template
  const downloadTemplate = () => {
    setTemplateDownloading(true)

    // Simulate download
    setTimeout(() => {
      setTemplateDownloading(false)
      // In a real app, this would trigger a file download
      alert("Template downloaded successfully!")
    }, 1500)
  }

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Import Opportunities</h2>
          <p className="text-muted-foreground">
            Add opportunities manually from websites or import multiple opportunities from a spreadsheet.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowImportHistory(!showImportHistory)}>
            {showImportHistory ? "Hide History" : "Show Import History"}
          </Button>
        </div>
      </div>

      {showImportHistory && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Imports</CardTitle>
            <CardDescription>History of your recently imported opportunities</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Source</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>Organization</TableHead>
                  <TableHead>Import Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentImports.map((imp) => (
                  <TableRow key={imp.id}>
                    <TableCell>
                      <Badge variant="outline">
                        {imp.source === "URL Import" ? (
                          <Globe className="mr-1 h-3 w-3" />
                        ) : (
                          <FileSpreadsheet className="mr-1 h-3 w-3" />
                        )}
                        {imp.source}
                      </Badge>
                    </TableCell>
                    <TableCell>{imp.title}</TableCell>
                    <TableCell>{imp.organization}</TableCell>
                    <TableCell>{formatDate(imp.importDate)}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          imp.status === "Success"
                            ? "bg-green-100 text-green-800"
                            : imp.status === "Failed"
                              ? "bg-red-100 text-red-800"
                              : "bg-yellow-100 text-yellow-800"
                        }
                      >
                        {imp.status === "Success" ? (
                          <Check className="mr-1 h-3 w-3" />
                        ) : imp.status === "Failed" ? (
                          <X className="mr-1 h-3 w-3" />
                        ) : (
                          <AlertCircle className="mr-1 h-3 w-3" />
                        )}
                        {imp.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {imp.url ? (
                        <Button variant="ghost" size="sm" asChild>
                          <a href={imp.url} target="_blank" rel="noopener noreferrer" className="flex items-center">
                            View Source
                            <ArrowRight className="ml-1 h-3 w-3" />
                          </a>
                        </Button>
                      ) : (
                        <Button variant="ghost" size="sm">
                          View Details
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="url" className="flex items-center gap-2">
            <Link className="h-4 w-4" />
            Import from URL
          </TabsTrigger>
          <TabsTrigger value="excel" className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4" />
            Import from Excel
          </TabsTrigger>
        </TabsList>

        <TabsContent value="url" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Import from Website URL</CardTitle>
              <CardDescription>
                Enter the URL of an opportunity page to automatically extract information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleUrlSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="url">Opportunity URL</Label>
                  <div className="flex gap-2">
                    <Input
                      id="url"
                      placeholder="https://example.com/opportunity"
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      className="flex-1"
                    />
                    <Button type="submit" disabled={isUrlProcessing || !urlInput}>
                      {isUrlProcessing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing
                        </>
                      ) : (
                        "Extract Info"
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Paste the full URL of the opportunity page. We'll try to automatically extract the details.
                  </p>
                </div>

                {isUrlProcessing && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Extracting information...</span>
                      <span>{urlProcessingProgress}%</span>
                    </div>
                    <Progress value={urlProcessingProgress} className="h-2" />
                  </div>
                )}

                {urlProcessingResult && (
                  <Alert
                    variant="default"
                    className={
                      urlProcessingResult.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                    }
                  >
                    {urlProcessingResult.success ? (
                      <Check className="h-4 w-4 text-green-600" />
                    ) : (
                      <X className="h-4 w-4 text-red-600" />
                    )}
                    <AlertTitle>{urlProcessingResult.success ? "Success" : "Error"}</AlertTitle>
                    <AlertDescription>{urlProcessingResult.message}</AlertDescription>
                  </Alert>
                )}

                {urlPreview && (
                  <div className="space-y-4 border rounded-md p-4">
                    <div className="flex justify-between items-start">
                      <h3 className="font-medium">Extracted Information</h3>
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        Preview
                      </Badge>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label>Title</Label>
                        <div className="p-2 border rounded-md bg-muted/50">{urlPreview.title}</div>
                      </div>
                      <div className="space-y-2">
                        <Label>Organization</Label>
                        <div className="p-2 border rounded-md bg-muted/50">{urlPreview.organization}</div>
                      </div>
                      <div className="space-y-2">
                        <Label>Type</Label>
                        <div className="p-2 border rounded-md bg-muted/50">{urlPreview.type}</div>
                      </div>
                      <div className="space-y-2">
                        <Label>Deadline</Label>
                        <div className="p-2 border rounded-md bg-muted/50">{urlPreview.deadline}</div>
                      </div>
                      <div className="space-y-2">
                        <Label>Location</Label>
                        <div className="p-2 border rounded-md bg-muted/50">{urlPreview.location}</div>
                      </div>
                      <div className="space-y-2">
                        <Label>Application Fee</Label>
                        <div className="p-2 border rounded-md bg-muted/50">${urlPreview.fee}</div>
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label>Categories</Label>
                        <div className="p-2 border rounded-md bg-muted/50 flex flex-wrap gap-1">
                          {urlPreview.categories.map((category: string) => (
                            <Badge key={category} variant="secondary">
                              {category}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label>Description</Label>
                        <div className="p-2 border rounded-md bg-muted/50">{urlPreview.description}</div>
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label>Eligibility</Label>
                        <div className="p-2 border rounded-md bg-muted/50">{urlPreview.eligibility}</div>
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label>Requirements</Label>
                        <div className="p-2 border rounded-md bg-muted/50">
                          <ul className="list-disc pl-5 space-y-1">
                            {urlPreview.requirements.map((req: string, index: number) => (
                              <li key={index}>{req}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="notes">Additional Notes (Optional)</Label>
                      <Textarea
                        id="notes"
                        placeholder="Add any additional notes about this opportunity"
                        value={urlNotes}
                        onChange={(e) => setUrlNotes(e.target.value)}
                      />
                    </div>

                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setUrlPreview(null)}>
                        Cancel
                      </Button>
                      <Button>Import Opportunity</Button>
                    </div>
                  </div>
                )}
              </form>
            </CardContent>
            <CardFooter className="flex flex-col items-start border-t px-6 py-4">
              <h3 className="font-medium mb-2">Tips for URL Import</h3>
              <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                <li>Use the direct URL of the opportunity page, not a general website homepage</li>
                <li>Some websites may not be compatible with automatic extraction</li>
                <li>Always review the extracted information before importing</li>
                <li>If extraction fails, you can manually enter the opportunity details</li>
              </ul>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="excel" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Import from Excel or CSV</CardTitle>
              <CardDescription>Upload a spreadsheet with multiple opportunities to import them in bulk</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div className="space-y-1">
                    <h3 className="font-medium">Excel Template</h3>
                    <p className="text-sm text-muted-foreground">
                      Download our template to ensure your data is formatted correctly
                    </p>
                  </div>
                  <Button variant="outline" onClick={downloadTemplate} disabled={templateDownloading}>
                    {templateDownloading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Downloading...
                      </>
                    ) : (
                      <>
                        <Download className="mr-2 h-4 w-4" />
                        Download Template
                      </>
                    )}
                  </Button>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="font-medium">Upload Your File</h3>

                  {!isFileUploaded ? (
                    <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                      <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                      <h4 className="font-medium mb-1">Drag and drop your file here</h4>
                      <p className="text-sm text-muted-foreground mb-4">
                        Supports Excel (.xlsx, .xls) and CSV (.csv) files
                      </p>
                      <div className="flex gap-2">
                        <Label
                          htmlFor="file-upload"
                          className="cursor-pointer bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-md text-sm font-medium"
                        >
                          Browse Files
                        </Label>
                        <Input
                          id="file-upload"
                          type="file"
                          accept=".xlsx,.xls,.csv"
                          className="hidden"
                          onChange={handleFileUpload}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="border rounded-md p-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileSpreadsheet className="h-6 w-6 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{fileName}</p>
                            <p className="text-xs text-muted-foreground">Uploaded just now</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => setIsFileUploaded(false)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>

                      {!showExcelPreview && (
                        <div className="flex justify-end">
                          <Button onClick={processExcelFile} disabled={isExcelProcessing}>
                            {isExcelProcessing ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Processing...
                              </>
                            ) : (
                              "Process File"
                            )}
                          </Button>
                        </div>
                      )}

                      {isExcelProcessing && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Processing file...</span>
                            <span>{excelProcessingProgress}%</span>
                          </div>
                          <Progress value={excelProcessingProgress} className="h-2" />
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {showExcelPreview && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">Preview & Field Mapping</h3>
                      <Badge variant="outline" className="bg-blue-100 text-blue-800">
                        3 opportunities found
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        Map each column in your spreadsheet to the corresponding field in our system
                      </p>

                      <ScrollArea className="h-[400px] rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[180px]">Column</TableHead>
                              <TableHead>Sample Data</TableHead>
                              <TableHead className="w-[200px]">Map To Field</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {Object.keys(excelPreviewData[0]).map((key, index) => (
                              <TableRow key={key}>
                                <TableCell className="font-medium">Column {index + 1}</TableCell>
                                <TableCell>
                                  <div className="max-w-[300px] truncate">
                                    {excelPreviewData.map((row, i) => (
                                      <div key={i} className={i > 0 ? "text-muted-foreground" : ""}>
                                        {row[key as keyof typeof row]}
                                        {i < excelPreviewData.length - 1 && ", "}
                                      </div>
                                    ))}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Select
                                    value={fieldMapping[index]}
                                    onValueChange={(value) => handleFieldMappingChange(index, value)}
                                  >
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {fieldMappingOptions.map((option) => (
                                        <SelectItem key={option.value} value={option.value}>
                                          {option.label}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </div>

                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Import Options</AlertTitle>
                      <AlertDescription>
                        <div className="space-y-2 mt-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox id="skip-header" defaultChecked />
                            <Label htmlFor="skip-header">Skip header row</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="update-existing" />
                            <Label htmlFor="update-existing">Update existing opportunities if found</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="skip-errors" defaultChecked />
                            <Label htmlFor="skip-errors">Skip rows with errors</Label>
                          </div>
                        </div>
                      </AlertDescription>
                    </Alert>

                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowExcelPreview(false)
                          setIsFileUploaded(false)
                          setFileName("")
                        }}
                      >
                        Cancel
                      </Button>
                      <Button onClick={importFromExcel} disabled={isExcelProcessing}>
                        {isExcelProcessing ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Importing...
                          </>
                        ) : (
                          "Import Opportunities"
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex flex-col items-start border-t px-6 py-4">
              <h3 className="font-medium mb-2">Tips for Excel Import</h3>
              <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                <li>Use our template for the best results</li>
                <li>Make sure your data is properly formatted (dates, URLs, etc.)</li>
                <li>You can import up to 100 opportunities at once</li>
                <li>Required fields: Title, Organization, Type, and Deadline</li>
                <li>For large imports, the process may take a few minutes</li>
              </ul>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" className="w-full">
            <FileUp className="mr-2 h-4 w-4" />
            Need help with importing opportunities?
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Import Help & Resources</DialogTitle>
            <DialogDescription>Learn how to effectively import opportunities from various sources</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <h3 className="font-medium">Video Tutorials</h3>
              <div className="grid grid-cols-2 gap-2">
                <div className="border rounded-md p-3 flex flex-col">
                  <div className="bg-muted aspect-video rounded-md mb-2 flex items-center justify-center">
                    <Play className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h4 className="text-sm font-medium">URL Import Tutorial</h4>
                  <p className="text-xs text-muted-foreground">3:45 min</p>
                </div>
                <div className="border rounded-md p-3 flex flex-col">
                  <div className="bg-muted aspect-video rounded-md mb-2 flex items-center justify-center">
                    <Play className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h4 className="text-sm font-medium">Excel Import Guide</h4>
                  <p className="text-xs text-muted-foreground">5:12 min</p>
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <h3 className="font-medium">Frequently Asked Questions</h3>
              <div className="space-y-2">
                <div className="border rounded-md p-3">
                  <h4 className="text-sm font-medium mb-1">What websites work best with URL import?</h4>
                  <p className="text-xs text-muted-foreground">
                    Our system works best with major opportunity platforms like CaFÉ, Residency Unlimited, FilmFreeway,
                    and Coverfly. Many institutional websites also work well.
                  </p>
                </div>
                <div className="border rounded-md p-3">
                  <h4 className="text-sm font-medium mb-1">How do I format dates in my Excel file?</h4>
                  <p className="text-xs text-muted-foreground">
                    Use YYYY-MM-DD format (e.g., 2025-06-30) for best results. Our system will try to interpret other
                    date formats, but this format ensures accuracy.
                  </p>
                </div>
                <div className="border rounded-md p-3">
                  <h4 className="text-sm font-medium mb-1">Can I import opportunities from my email?</h4>
                  <p className="text-xs text-muted-foreground">
                    Not directly, but you can forward opportunity emails to your dedicated import email address (found
                    in Settings). Our system will attempt to extract the information.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" asChild>
              <a href="#" target="_blank" rel="noopener noreferrer">
                View Full Documentation
              </a>
            </Button>
            <Button>Contact Support</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
