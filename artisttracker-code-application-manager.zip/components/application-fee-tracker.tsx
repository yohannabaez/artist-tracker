"use client"

import { useState } from "react"
import { DollarSign, Download, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function ApplicationFeeTracker() {
  const [year, setYear] = useState("2025")

  const feeData = [
    { id: 1, date: "2025-01-15", name: "International Art Prize", type: "Competition", amount: 50 },
    { id: 2, date: "2025-02-03", name: "Summer Art Residency", type: "Residency", amount: 35 },
    { id: 3, date: "2025-02-28", name: "Emerging Artist Grant", type: "Grant", amount: 25 },
    { id: 4, date: "2025-03-10", name: "Digital Media Festival", type: "Festival", amount: 40 },
    { id: 5, date: "2025-04-05", name: "Museum Exhibition Open Call", type: "Exhibition", amount: 30 },
    { id: 6, date: "2025-04-22", name: "Public Art Commission", type: "Commission", amount: 75 },
    { id: 7, date: "2025-05-18", name: "Artist Book Award", type: "Competition", amount: 45 },
    { id: 8, date: "2025-06-07", name: "Fall Residency Program", type: "Residency", amount: 50 },
  ]

  const totalSpent = feeData.reduce((sum, item) => sum + item.amount, 0)

  const feesByType = feeData.reduce((acc, item) => {
    acc[item.type] = (acc[item.type] || 0) + item.amount
    return acc
  }, {})

  const feesByMonth = feeData.reduce((acc, item) => {
    const month = new Date(item.date).getMonth()
    acc[month] = (acc[month] || 0) + item.amount
    return acc
  }, {})

  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Application Fee Tracker</h2>
        <div className="flex items-center gap-2">
          <Select value={year} onValueChange={setYear}>
            <SelectTrigger className="w-[100px]">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Download className="h-4 w-4" />
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Fee
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Application Fee</DialogTitle>
                <DialogDescription>Record a new application fee payment</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="date" className="text-right">
                    Date
                  </Label>
                  <Input id="date" type="date" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Opportunity
                  </Label>
                  <Input id="name" placeholder="Name of opportunity" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="type" className="text-right">
                    Type
                  </Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="grant">Grant</SelectItem>
                      <SelectItem value="residency">Residency</SelectItem>
                      <SelectItem value="fellowship">Fellowship</SelectItem>
                      <SelectItem value="exhibition">Exhibition</SelectItem>
                      <SelectItem value="festival">Festival</SelectItem>
                      <SelectItem value="competition">Competition</SelectItem>
                      <SelectItem value="commission">Commission</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="amount" className="text-right">
                    Amount
                  </Label>
                  <div className="col-span-3 flex items-center">
                    <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                    <Input id="amount" type="number" placeholder="0.00" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Save Fee</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Total Spent</CardTitle>
            <CardDescription>Application fees in {year}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${totalSpent}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Average Fee</CardTitle>
            <CardDescription>Per application</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${(totalSpent / feeData.length).toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Applications</CardTitle>
            <CardDescription>Total count</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{feeData.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Fee History</CardTitle>
          <CardDescription>Record of all application fees paid</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="list">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="list">List View</TabsTrigger>
              <TabsTrigger value="summary">Summary</TabsTrigger>
            </TabsList>
            <TabsContent value="list">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Opportunity</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {feeData.map((fee) => (
                    <TableRow key={fee.id}>
                      <TableCell>{new Date(fee.date).toLocaleDateString()}</TableCell>
                      <TableCell>{fee.name}</TableCell>
                      <TableCell>{fee.type}</TableCell>
                      <TableCell className="text-right">${fee.amount}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>
            <TabsContent value="summary">
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Fees by Type</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Object.entries(feesByType).map(([type, amount]) => (
                        <TableRow key={type}>
                          <TableCell>{type}</TableCell>
                          <TableCell className="text-right">${amount}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Monthly Spending</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Month</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {months.map((month, index) => (
                        <TableRow key={month}>
                          <TableCell>{month}</TableCell>
                          <TableCell className="text-right">${feesByMonth[index] || 0}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
