"use client"

import { useState } from "react"
import { CalendarPlus, ExternalLink, Filter, ThumbsDown, ThumbsUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function RecommendedOpportunities() {
  const [filter, setFilter] = useState("all")

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Recommended Opportunities</h2>
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="grants">Grants</SelectItem>
              <SelectItem value="residencies">Residencies</SelectItem>
              <SelectItem value="fellowships">Fellowships</SelectItem>
              <SelectItem value="exhibitions">Exhibitions</SelectItem>
              <SelectItem value="festivals">Festivals</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>Digital Art Fellowship</CardTitle>
              <Badge>98% Match</Badge>
            </div>
            <CardDescription>Tech Arts Foundation</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">$12,000 fellowship for artists exploring the intersection of technology and art.</p>
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge variant="outline">Digital Art</Badge>
              <Badge variant="outline">Technology</Badge>
              <Badge variant="outline">Fellowship</Badge>
            </div>
            <div className="mt-3">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$0</span>
              </p>
              <p className="text-sm font-medium">
                Deadline: <span className="text-muted-foreground">June 15, 2025</span>
              </p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <ThumbsUp className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <ThumbsDown className="h-4 w-4" />
              </Button>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button>View Details</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Digital Art Fellowship</DialogTitle>
                  <DialogDescription>Tech Arts Foundation</DialogDescription>
                </DialogHeader>
                <Tabs defaultValue="details">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="match">Match Analysis</TabsTrigger>
                    <TabsTrigger value="requirements">Requirements</TabsTrigger>
                  </TabsList>
                  <TabsContent value="details" className="space-y-4 py-4">
                    <div>
                      <h3 className="font-medium mb-2">Description</h3>
                      <p className="text-sm text-muted-foreground">
                        The Digital Art Fellowship supports artists exploring the intersection of technology and art.
                        Fellows receive a $12,000 stipend, mentorship from established digital artists, and exhibition
                        opportunities.
                      </p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Eligibility</h3>
                      <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                        <li>Artists working in digital media, new media, or technology-based art</li>
                        <li>At least 3 years of professional practice</li>
                        <li>Demonstrated commitment to innovation in the field</li>
                        <li>No geographic restrictions</li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Timeline</h3>
                      <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                        <li>Application Deadline: June 15, 2025</li>
                        <li>Notification: August 1, 2025</li>
                        <li>Fellowship Period: September 2025 - August 2026</li>
                      </ul>
                    </div>
                  </TabsContent>
                  <TabsContent value="match" className="space-y-4 py-4">
                    <div>
                      <h3 className="font-medium mb-2">Why This Matches Your Profile</h3>
                      <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-2">
                        <li>
                          <span className="font-medium">Your Digital Art Focus:</span> Your portfolio shows strong work
                          in interactive digital installations, which aligns perfectly with this fellowship's focus.
                        </li>
                        <li>
                          <span className="font-medium">Technology Integration:</span> Your artist statement emphasizes
                          the role of technology in your creative process, matching the fellowship's mission.
                        </li>
                        <li>
                          <span className="font-medium">Experience Level:</span> Your 4 years of professional practice
                          meets their minimum requirement of 3 years.
                        </li>
                        <li>
                          <span className="font-medium">Previous Success:</span> You've been successful with similar
                          opportunities in the past (Tech Art Prize finalist 2023).
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Match Score Breakdown</h3>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Medium/Focus: 100%</div>
                        <div>Experience Level: 95%</div>
                        <div>Geographic Eligibility: 100%</div>
                        <div>Past Success Pattern: 95%</div>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="requirements" className="space-y-4 py-4">
                    <div>
                      <h3 className="font-medium mb-2">Application Requirements</h3>
                      <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                        <li>Artist statement (500 words max)</li>
                        <li>Project proposal for fellowship period (1000 words max)</li>
                        <li>Portfolio of 10-15 works with descriptions</li>
                        <li>CV/Resume</li>
                        <li>Two professional references</li>
                        <li>Optional: Video introduction (2 minutes max)</li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Selection Criteria</h3>
                      <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                        <li>Artistic excellence and innovation</li>
                        <li>Technical proficiency</li>
                        <li>Potential impact of proposed project</li>
                        <li>Alignment with fellowship's mission</li>
                      </ul>
                    </div>
                  </TabsContent>
                </Tabs>
                <DialogFooter className="flex justify-between">
                  <Button variant="outline">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Visit Website
                  </Button>
                  <Button>
                    <CalendarPlus className="mr-2 h-4 w-4" />
                    Add to Calendar
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>Experimental Media Residency</CardTitle>
              <Badge>92% Match</Badge>
            </div>
            <CardDescription>Contemporary Arts Center</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">
              Three-month residency with studio space, housing, and $5,000 stipend for experimental media artists.
            </p>
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge variant="outline">Experimental</Badge>
              <Badge variant="outline">Media Arts</Badge>
              <Badge variant="outline">Residency</Badge>
            </div>
            <div className="mt-3">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$25</span>
              </p>
              <p className="text-sm font-medium">
                Deadline: <span className="text-muted-foreground">July 30, 2025</span>
              </p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <ThumbsUp className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <ThumbsDown className="h-4 w-4" />
              </Button>
            </div>
            <Button>View Details</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>Emerging Curator Grant</CardTitle>
              <Badge>85% Match</Badge>
            </div>
            <CardDescription>Museum of Contemporary Art</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">
              $8,000 grant to support emerging curators developing innovative exhibition concepts.
            </p>
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge variant="outline">Curatorial</Badge>
              <Badge variant="outline">Exhibition</Badge>
              <Badge variant="outline">Grant</Badge>
            </div>
            <div className="mt-3">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$0</span>
              </p>
              <p className="text-sm font-medium">
                Deadline: <span className="text-muted-foreground">August 15, 2025</span>
              </p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <ThumbsUp className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <ThumbsDown className="h-4 w-4" />
              </Button>
            </div>
            <Button>View Details</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>Public Art Commission</CardTitle>
              <Badge>80% Match</Badge>
            </div>
            <CardDescription>City Arts Commission</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">$25,000 commission for a public art installation in the downtown arts district.</p>
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge variant="outline">Public Art</Badge>
              <Badge variant="outline">Installation</Badge>
              <Badge variant="outline">Commission</Badge>
            </div>
            <div className="mt-3">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$0</span>
              </p>
              <p className="text-sm font-medium">
                Deadline: <span className="text-muted-foreground">September 1, 2025</span>
              </p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <ThumbsUp className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <ThumbsDown className="h-4 w-4" />
              </Button>
            </div>
            <Button>View Details</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
