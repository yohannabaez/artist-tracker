"use client"

import { useState } from "react"
import { RefreshCw, Plus, Check, AlertCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample platform integration data
const platforms = [
  {
    id: "cafe",
    name: "CaFÉ (Call for Entry)",
    url: "https://artist.callforentry.org",
    connected: true,
    lastSync: "2025-04-10T14:30:00",
    logo: "cafe-logo.png",
    requiresAuth: true,
    description: "The leading online application and jurying system for art and cultural opportunities.",
  },
  {
    id: "ru",
    name: "Residency Unlimited",
    url: "https://residencyunlimited.org",
    connected: true,
    lastSync: "2025-04-09T10:15:00",
    logo: "ru-logo.png",
    requiresAuth: false,
    description: "A platform for artist residencies and cultural exchange programs.",
  },
  {
    id: "rivet",
    name: "Rivet",
    url: "https://rivet.es",
    connected: false,
    lastSync: null,
    logo: "rivet-logo.png",
    requiresAuth: true,
    description: "A platform for contemporary art calls and opportunities in Europe.",
  },
  {
    id: "china",
    name: "China Residencies",
    url: "https://www.chinaresidencies.com",
    connected: false,
    lastSync: null,
    logo: "china-logo.png",
    requiresAuth: false,
    description: "A network of artist residencies in China and resource for cultural exchange.",
  },
  {
    id: "cc",
    name: "Creative Capital",
    url: "https://creative-capital.org",
    connected: true,
    lastSync: "2025-04-08T16:45:00",
    logo: "cc-logo.png",
    requiresAuth: true,
    description: "A nonprofit organization supporting innovative and adventurous artists.",
  },
]

export function OpportunityIntegration() {
  const [integrations, setIntegrations] = useState(platforms)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isSyncing, setIsSyncing] = useState(false)
  const [syncProgress, setSyncProgress] = useState(0)
  const [selectedPlatform, setSelectedPlatform] = useState<any>(null)

  // Toggle connection status
  const toggleConnection = (id: string) => {
    setIntegrations(
      integrations.map((platform) =>
        platform.id === id
          ? {
              ...platform,
              connected: !platform.connected,
              lastSync: platform.connected ? null : new Date().toISOString(),
            }
          : platform,
      ),
    )
  }

  // Format date for display
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Never"
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    })
  }

  // Simulate syncing
  const syncPlatform = (id: string) => {
    setIsSyncing(true)
    setSyncProgress(0)

    const interval = setInterval(() => {
      setSyncProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsSyncing(false)

          // Update last sync time
          setIntegrations(
            integrations.map((platform) =>
              platform.id === id
                ? {
                    ...platform,
                    lastSync: new Date().toISOString(),
                  }
                : platform,
            ),
          )

          return 0
        }
        return prev + 10
      })
    }, 300)
  }

  // Simulate connecting to a platform
  const connectToPlatform = (platform: any) => {
    setIsConnecting(true)

    // Simulate API connection
    setTimeout(() => {
      toggleConnection(platform.id)
      setIsConnecting(false)
      setSelectedPlatform(null)
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Platform Integrations</h2>
          <p className="text-muted-foreground">
            Connect to opportunity platforms to automatically import and track applications.
          </p>
        </div>
        <Button variant="outline" onClick={() => syncPlatform("all")}>
          <RefreshCw className={`mr-2 h-4 w-4 ${isSyncing ? "animate-spin" : ""}`} />
          Sync All
        </Button>
      </div>

      {isSyncing && (
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Syncing opportunities...</span>
            <span>{syncProgress}%</span>
          </div>
          <Progress value={syncProgress} className="h-2" />
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {integrations.map((platform) => (
          <Card key={platform.id}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle>{platform.name}</CardTitle>
                <Switch
                  checked={platform.connected}
                  onCheckedChange={() => {
                    if (!platform.connected) {
                      setSelectedPlatform(platform)
                    } else {
                      toggleConnection(platform.id)
                    }
                  }}
                />
              </div>
              <CardDescription>{platform.description}</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <span className={platform.connected ? "text-green-600" : "text-muted-foreground"}>
                    {platform.connected ? "Connected" : "Disconnected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Synced:</span>
                  <span>{formatDate(platform.lastSync)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Authentication:</span>
                  <span>{platform.requiresAuth ? "Required" : "Not Required"}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="pt-2">
              <div className="flex justify-between w-full">
                <Button variant="outline" size="sm" asChild>
                  <a href={platform.url} target="_blank" rel="noopener noreferrer">
                    Visit Site
                  </a>
                </Button>
                {platform.connected && (
                  <Button size="sm" onClick={() => syncPlatform(platform.id)} disabled={isSyncing}>
                    <RefreshCw className={`mr-2 h-4 w-4 ${isSyncing ? "animate-spin" : ""}`} />
                    Sync Now
                  </Button>
                )}
              </div>
            </CardFooter>
          </Card>
        ))}

        <Card className="flex flex-col items-center justify-center p-6 border-dashed">
          <Plus className="h-8 w-8 mb-4 text-muted-foreground" />
          <h3 className="text-lg font-medium mb-2">Add Custom Platform</h3>
          <p className="text-sm text-muted-foreground text-center mb-4">
            Connect to other opportunity platforms or RSS feeds
          </p>
          <Button>Add Platform</Button>
        </Card>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Integration Information</AlertTitle>
        <AlertDescription>
          Connecting to platforms allows the system to automatically import opportunities and track your applications.
          Some platforms may require authentication or API keys. Your credentials are securely stored and never shared.
        </AlertDescription>
      </Alert>

      {/* Connection Dialog */}
      {selectedPlatform && (
        <Dialog open={!!selectedPlatform} onOpenChange={() => setSelectedPlatform(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Connect to {selectedPlatform.name}</DialogTitle>
              <DialogDescription>
                {selectedPlatform.requiresAuth
                  ? "Enter your credentials to connect to this platform."
                  : "Configure how you want to connect to this platform."}
              </DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="credentials" className="mt-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="credentials">Credentials</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>

              <TabsContent value="credentials" className="space-y-4 py-4">
                {selectedPlatform.requiresAuth ? (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Username or Email</Label>
                      <Input id="username" placeholder="Enter your username or email" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input id="password" type="password" placeholder="Enter your password" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="remember" className="h-4 w-4" />
                      <Label htmlFor="remember" className="text-sm">
                        Remember credentials (encrypted)
                      </Label>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Alert className="bg-green-50 border-green-200">
                      <Check className="h-4 w-4 text-green-600" />
                      <AlertTitle>No Authentication Required</AlertTitle>
                      <AlertDescription>
                        This platform doesn't require authentication. You can connect directly.
                      </AlertDescription>
                    </Alert>
                    <div className="space-y-2">
                      <Label htmlFor="custom-url">Custom URL (Optional)</Label>
                      <Input id="custom-url" placeholder="Enter a custom URL if needed" />
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="settings" className="space-y-4 py-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Auto-sync opportunities</Label>
                      <p className="text-sm text-muted-foreground">Automatically sync new opportunities daily</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Notifications</Label>
                      <p className="text-sm text-muted-foreground">Receive notifications for new opportunities</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Filter by preferences</Label>
                      <p className="text-sm text-muted-foreground">
                        Only import opportunities matching your preferences
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedPlatform(null)}>
                Cancel
              </Button>
              <Button onClick={() => connectToPlatform(selectedPlatform)} disabled={isConnecting}>
                {isConnecting ? "Connecting..." : "Connect"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
