"use client"

import { useState } from "react"
import { CalendarClock, ExternalLink, Eye } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"

export function UpcomingDeadlines() {
  const [reminders, setReminders] = useState({
    "emerging-artist": true,
    "city-fellowship": true,
    "summer-residency": false,
    "art-prize": true,
  })

  const toggleReminder = (id: string) => {
    setReminders((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Upcoming Deadlines</h2>
        <Button variant="outline" size="sm">
          <CalendarClock className="mr-2 h-4 w-4" />
          View Calendar
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>Emerging Artist Grant</CardTitle>
              <Badge variant="outline" className="bg-orange-100 text-orange-800 hover:bg-orange-100">
                3 days left
              </Badge>
            </div>
            <CardDescription>National Arts Foundation</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">$5,000 grant for emerging artists working in digital media.</p>
            <div className="flex items-center justify-between mt-2">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$25</span>
              </p>
              <div className="flex items-center space-x-2">
                <Label htmlFor="emerging-artist" className="text-xs">
                  Reminder
                </Label>
                <Switch
                  id="emerging-artist"
                  checked={reminders["emerging-artist"]}
                  onCheckedChange={() => toggleReminder("emerging-artist")}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Eye className="mr-2 h-4 w-4" />
                  Details
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Emerging Artist Grant</DialogTitle>
                  <DialogDescription>National Arts Foundation</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div>
                    <h3 className="font-medium mb-2">Description</h3>
                    <p className="text-sm text-muted-foreground">
                      This grant supports emerging artists working in digital media. Applicants must have been
                      practicing for less than 5 years and demonstrate innovative approaches to digital art.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Eligibility</h3>
                    <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                      <li>Artists with less than 5 years professional experience</li>
                      <li>Working primarily in digital media</li>
                      <li>U.S. residents</li>
                      <li>Not enrolled in degree program</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Requirements</h3>
                    <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                      <li>Artist statement (500 words max)</li>
                      <li>Project proposal (1000 words max)</li>
                      <li>Portfolio (10 images or 5 minutes of video)</li>
                      <li>CV/Resume</li>
                      <li>Two references</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Notes</h3>
                    <Textarea placeholder="Add your notes about this opportunity..." />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Visit Website
                  </Button>
                  <Button>Start Application</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Button size="sm">Start Application</Button>
          </CardFooter>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>City Artist Fellowship</CardTitle>
              <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                7 days left
              </Badge>
            </div>
            <CardDescription>Metropolitan Arts Council</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">$10,000 fellowship for artists working in public spaces.</p>
            <div className="flex items-center justify-between mt-2">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$0</span>
              </p>
              <div className="flex items-center space-x-2">
                <Label htmlFor="city-fellowship" className="text-xs">
                  Reminder
                </Label>
                <Switch
                  id="city-fellowship"
                  checked={reminders["city-fellowship"]}
                  onCheckedChange={() => toggleReminder("city-fellowship")}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Button variant="outline" size="sm">
              <Eye className="mr-2 h-4 w-4" />
              Details
            </Button>
            <Button size="sm">Start Application</Button>
          </CardFooter>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>Summer Art Residency</CardTitle>
              <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                14 days left
              </Badge>
            </div>
            <CardDescription>Mountain Creative Retreat</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">Two-month summer residency with studio space and housing.</p>
            <div className="flex items-center justify-between mt-2">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$35</span>
              </p>
              <div className="flex items-center space-x-2">
                <Label htmlFor="summer-residency" className="text-xs">
                  Reminder
                </Label>
                <Switch
                  id="summer-residency"
                  checked={reminders["summer-residency"]}
                  onCheckedChange={() => toggleReminder("summer-residency")}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Button variant="outline" size="sm">
              <Eye className="mr-2 h-4 w-4" />
              Details
            </Button>
            <Button size="sm">Start Application</Button>
          </CardFooter>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>International Art Prize</CardTitle>
              <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                21 days left
              </Badge>
            </div>
            <CardDescription>Global Arts Foundation</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm">$15,000 prize for innovative contemporary art.</p>
            <div className="flex items-center justify-between mt-2">
              <p className="text-sm font-medium">
                Application Fee: <span className="text-muted-foreground">$50</span>
              </p>
              <div className="flex items-center space-x-2">
                <Label htmlFor="art-prize" className="text-xs">
                  Reminder
                </Label>
                <Switch
                  id="art-prize"
                  checked={reminders["art-prize"]}
                  onCheckedChange={() => toggleReminder("art-prize")}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Button variant="outline" size="sm">
              <Eye className="mr-2 h-4 w-4" />
              Details
            </Button>
            <Button size="sm">Start Application</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
