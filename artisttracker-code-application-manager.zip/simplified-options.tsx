import { Check } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function SimplifiedOptions() {
  return (
    <div className="container py-8 max-w-5xl">
      <h1 className="text-3xl font-bold mb-6">Implementation Options</h1>
      <p className="mb-8 max-w-3xl">
        Depending on your technical expertise and budget, here are three approaches to making the Artist Application
        Manager a reality.
      </p>

      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>DIY Approach</CardTitle>
            <CardDescription>Build everything yourself</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Requirements</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Programming knowledge (React, Node.js)</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Database experience</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Server management skills</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Time commitment (3-6 months)</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Costs</h3>
              <ul className="space-y-1 text-sm">
                <li>Hosting: $20-50/month</li>
                <li>Database: $10-50/month</li>
                <li>Storage: $5-20/month</li>
                <li>Domain: $10-15/year</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Pros</h3>
              <ul className="space-y-1 text-sm list-disc pl-5">
                <li>Complete control</li>
                <li>Customizable</li>
                <li>No platform limitations</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Cons</h3>
              <ul className="space-y-1 text-sm list-disc pl-5">
                <li>Technically challenging</li>
                <li>Time-consuming</li>
                <li>Ongoing maintenance</li>
              </ul>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Learn More</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Low-Code Approach</CardTitle>
            <CardDescription>Use managed services</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Requirements</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Basic programming knowledge</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Familiarity with APIs</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Understanding of cloud services</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Time commitment (1-3 months)</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Costs</h3>
              <ul className="space-y-1 text-sm">
                <li>Supabase/Firebase: $25-100/month</li>
                <li>Vercel: $20-50/month</li>
                <li>Auth service: $20-50/month</li>
                <li>Domain: $10-15/year</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Pros</h3>
              <ul className="space-y-1 text-sm list-disc pl-5">
                <li>Faster development</li>
                <li>Less infrastructure management</li>
                <li>Scalable services</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Cons</h3>
              <ul className="space-y-1 text-sm list-disc pl-5">
                <li>Platform limitations</li>
                <li>Higher monthly costs</li>
                <li>Vendor lock-in</li>
              </ul>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" variant="secondary">
              Learn More
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hire a Developer</CardTitle>
            <CardDescription>Professional implementation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Requirements</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Budget for development</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Clear project requirements</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Project management</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span>Time commitment (minimal)</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Costs</h3>
              <ul className="space-y-1 text-sm">
                <li>Development: $10,000-30,000</li>
                <li>Ongoing hosting: $50-200/month</li>
                <li>Maintenance: $1,000-3,000/year</li>
                <li>Domain: $10-15/year</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Pros</h3>
              <ul className="space-y-1 text-sm list-disc pl-5">
                <li>Professional quality</li>
                <li>Faster time to market</li>
                <li>Technical support</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">Cons</h3>
              <ul className="space-y-1 text-sm list-disc pl-5">
                <li>Higher upfront cost</li>
                <li>Finding the right developer</li>
                <li>Communication challenges</li>
              </ul>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" variant="outline">
              Learn More
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
